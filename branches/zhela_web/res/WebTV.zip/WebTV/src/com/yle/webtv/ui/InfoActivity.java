package com.yle.webtv.ui;

import com.yle.webtv.R;

import android.app.Activity;
import android.os.Bundle;

public class InfoActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {		
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.info);
	}
	
}
