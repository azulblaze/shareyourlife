package com.yle.webtv.net;

import com.yle.webtv.service.ImagesUpdatingingService;
import com.yle.webtv.service.RssHandleService;
import com.yle.webtv.utils.CommonInfo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;
import android.util.Log;

public class ConnectionChangeReceiver extends BroadcastReceiver {

	public static final String RSS_FEED_UPDATING_EXTRA_NAME = "RSS_FEED_UPDATING_EXTRA_NAME";
	public static final int CONNECTION_CHANGE_RECEIVER_EXTRA_VALUE = 2;
	public static final String IMAGE_PDATING_EXTRA_NAME = "IMAGE_PDATING_EXTRA_NAME";
	public static final int IMAGE_UPDARING_EXTRA_VALUE = 1;

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO: if there's connection, services will start.
		if (hasGoodEnoughNetworkConnection(context)) {
			if (!CommonInfo.isServiceRunning(context, "RssHandleService")) {
				Intent itent = new Intent(context, RssHandleService.class);
				itent.putExtra(RSS_FEED_UPDATING_EXTRA_NAME,
						CONNECTION_CHANGE_RECEIVER_EXTRA_VALUE);
				context.startService(itent);
			}

			if (!CommonInfo.isServiceRunning(context,
					"ImagesUpdatingingService")) {
				Intent imageUpdatingIntent = new Intent(context,
						ImagesUpdatingingService.class);
				imageUpdatingIntent.putExtra(IMAGE_PDATING_EXTRA_NAME,
						IMAGE_UPDARING_EXTRA_VALUE);
				Log.d("imageservice", "imageservice  start 2222");
				context.startService(imageUpdatingIntent);
			}

		}
	}

	/**
	 * get the network connection status
	 * 
	 */
	public static boolean hasGoodEnoughNetworkConnection(Context context) {
		NetworkInfo info = ((ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE))
				.getActiveNetworkInfo();
		return hasGoodEnoughNetworkConnection(info, context);
	}

	public static boolean hasGoodEnoughNetworkConnection(NetworkInfo info,
			Context context) {
		if (info == null)
			return false;
		// Only update if WiFi or 3G is connected and not roaming
		int netType = info.getType();
		int netSubtype = info.getSubtype();
		if (netType == ConnectivityManager.TYPE_WIFI) {
			return info.isConnected();
		}
		if (netType == ConnectivityManager.TYPE_MOBILE
				&& netSubtype == TelephonyManager.NETWORK_TYPE_UMTS) {
			TelephonyManager telephonyManager = (TelephonyManager) context
					.getSystemService(Context.TELEPHONY_SERVICE);
			if (!telephonyManager.isNetworkRoaming()) {
				return info.isConnected();
			}
		}

		// 2.5 or GPRS or other connection will return from here.
		return true;
	}

}
