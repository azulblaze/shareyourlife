package com.yle.webtv.ui;

import com.yle.webtv.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SettingsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.settings);
		Intent i = this.getIntent();
		
		
		Button info_btn = (Button)this.findViewById(R.id.info_btn);
		Button app_market_btn = (Button)this.findViewById(R.id.appMarket_btn);
		info_btn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(SettingsActivity.this,InfoActivity.class);
				SettingsActivity.this.startActivity(intent);	
			}
			
		});
		
		app_market_btn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(android.net.Uri.parse("http://www.android.com/market"));
				SettingsActivity.this.startActivity(intent);
			}
			
		});
		
		if(i.getStringExtra("currentLang")!=null && i.getStringExtra("currentLang").equals("fi")){
			info_btn.setText(R.string.fi_str_info);
			app_market_btn.setText(R.string.fi_str_app_market);
		}else if(i.getStringExtra("currentLang")!=null && i.getStringExtra("currentLang").equals("swe")){
			info_btn.setText(R.string.swe_str_info);
			app_market_btn.setText(R.string.swe_str_app_market);
		}
	}

}
