package com.yle.webtv.search;
import com.yle.webtv.R;
import com.yle.webtv.player.VideoPlayer;
import com.yle.webtv.rss.Item.Items;
import android.app.Activity;
import android.app.SearchManager;
import android.app.SearchManager.OnCancelListener;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class SearchActivity extends Activity {

	private TextView mTextView;
	private ListView mListView;
	private Activity self = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		self = this;
		onSearchRequested();
		setContentView(R.layout.search);
		
		mTextView = (TextView)findViewById(R.id.tip);
		mListView = (ListView)findViewById(R.id.searchResults);
	    Intent intent = getIntent();
	    
	    if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
	      String query = intent.getStringExtra(SearchManager.QUERY);
	      if(query != null && !query.equals("")){
	    	  Log.i("query",query);
	    	  doSearch(query);
	      }
	     SearchManager searchManager =  (SearchManager) this.getSystemService(Context.SEARCH_SERVICE);
	     searchManager.setOnCancelListener(new OnCancelListener(){
			@Override
			public void onCancel() {
				self.finish();
			}
	     });
	    }
	}
	
	public void doSearch(String query){ 
		
		String keyword = "*"+query+"*";
		Cursor cursor = managedQuery(Items.ITEM_SEARCH_CONTENT_URI, null, null,
                new String[] {keyword}, null);
		if (cursor == null || (cursor!= null && cursor.getCount() == 0)) {
			// There are no results
			mTextView.setText(getString(R.string.no_results, new Object[] {query}));
		} else {
			mTextView.setText("");
			// Create a simple cursor adapter for the definitions and apply them to the ListView
			MyCusrorAdapter adapter = new MyCusrorAdapter(this,cursor);
			mListView.setAdapter(adapter);
			
			// Define the on-click listener for the list items
			mListView.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					
					String mediaLink = (String)view.getTag(R.id.mediaLink);
					Intent intent = new Intent(SearchActivity.this,
							VideoPlayer.class);
					intent.putExtra("uri",mediaLink);
					SearchActivity.this.startActivity(intent);
    
				}
			});
		}
	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		
		if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
		      String query = intent.getStringExtra(SearchManager.QUERY);
		      
		      if(query != null && !query.equals("")){
		    	  Log.i("query",query);
		    	  doSearch(query);
		      }
		    } 	 
	}

}
