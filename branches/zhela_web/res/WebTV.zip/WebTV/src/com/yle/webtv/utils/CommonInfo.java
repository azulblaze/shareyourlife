package com.yle.webtv.utils;

import java.util.List;

import com.yle.webtv.WebTv;

import android.app.ActivityManager;
import android.content.Context;
import android.util.Log;

public class CommonInfo {
	private static final String LOG_TAG = "serviceInfo";

	public static boolean isServiceRunning(Context context, String serviceName) {
		final ActivityManager activityManager = (ActivityManager) context.getSystemService(WebTv.ACTIVITY_SERVICE);
		final List<ActivityManager.RunningServiceInfo> services = activityManager
				.getRunningServices(Integer.MAX_VALUE);

		boolean isServiceFound = false;

		for (int i = 0; i < services.size(); i++) {
			Log.d(LOG_TAG, "Service Nr. " + i + " :" + services.get(i).service);

			Log.d(LOG_TAG,
					"Service Nr. " + i + " package name : "
							+ services.get(i).service.getPackageName());
			Log.d(LOG_TAG,
					"Service Nr. " + i + " class name : "
							+ services.get(i).service.getClassName());

			if ("com.yle.webtv".equals(services.get(i).service
					.getPackageName())) {

				Log.d(LOG_TAG, "packagename stimmt �berein !!!");
				// Log.d(LOG_TAG, "SpotService" + " : " +
				// services.get(i).service.getClassName());
				String fullServiceName = "com.yle.webtv.service." + serviceName;

				if (fullServiceName.equals(services.get(i).service.getClassName())) {
					isServiceFound = true;
				}
			}
		}
		if(isServiceFound)
			Log.d(LOG_TAG, "service is running!!!");

		return isServiceFound;
	}
}
