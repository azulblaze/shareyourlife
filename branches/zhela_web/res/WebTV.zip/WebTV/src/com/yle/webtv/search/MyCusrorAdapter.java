package com.yle.webtv.search;

import com.yle.webtv.R;
import com.yle.webtv.rss.Item.Items;
import com.yle.webtv.ui.EpisodeDetails;
import com.yle.webtv.ui.ImageCache;
import com.yle.webtv.ui.ImageCache.ImageCallback;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnTouchListener;
import android.widget.CursorAdapter;
import android.widget.TextView;
import android.widget.ImageView;

public class MyCusrorAdapter extends CursorAdapter {
	
	private Context context;
	private Cursor cursor;

	public MyCusrorAdapter(Context context,Cursor c) {
		super(context,c);
		this.context = context;
		this.cursor = c;	
	}
	@Override
	
		public View getView(int position, View convertView, ViewGroup parent){	
		
			if(convertView == null){
				LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = inflater.inflate(R.layout.image_and_text_row, null);	
			}
			
			cursor.moveToPosition(position);
			int titleIndex = cursor.getColumnIndex(Items.TITLE);
			String title = cursor.getString(titleIndex);
			int infoIndex = cursor.getColumnIndex(Items.INFO);
			String info = cursor.getString(infoIndex);
			int mediaLinkIndex = cursor.getColumnIndex(Items.LINK);
			String mediaLink = cursor.getString(mediaLinkIndex);
			int imageUrlIndex = cursor.getColumnIndex(Items.IMAGE);
			String imageUrl = cursor.getString(imageUrlIndex);
			int descIndex = cursor.getColumnIndex(Items.DESCRIPTION);
			String desc = cursor.getString(descIndex);
			
			Bitmap mBitmap = ImageCache.loadImage(imageUrl, 0, 0, new ImageCallback(){

				@Override
				public void imageLoaded(Bitmap bitmap, int channelId,
						int itemId, String imageUrl) {
				}
			});
			
			ImageView showDescriptionView = (ImageView)convertView.findViewById(R.id.description);
			showDescriptionView.setImageResource(R.drawable.expander_default);
			showDescriptionView.setTag(R.id.episode_desc,desc);
			showDescriptionView.setTag(R.id.episode_info,info);
			showDescriptionView.setTag(R.id.episode_title,title);
			showDescriptionView.setTag(R.id.imageLink,imageUrl);
			
			showDescriptionView.setOnTouchListener(new OnTouchListener(){

				@Override
				public boolean onTouch(View arg0, MotionEvent arg1) {
					if (arg1.getAction() == MotionEvent.ACTION_DOWN){
						((ImageView)arg0).setImageResource(R.drawable.expander_pressed);
					}
					if (arg1.getAction() == MotionEvent.ACTION_UP){
						((ImageView)arg0).setImageResource(R.drawable.expander_default);
						Intent intent = new Intent(context,EpisodeDetails.class);
						intent.putExtra("desc", arg0.getTag(R.id.episode_desc).toString());
						intent.putExtra("info", arg0.getTag(R.id.episode_info).toString());
						intent.putExtra("title", arg0.getTag(R.id.episode_title).toString());
						intent.putExtra("imageLink", arg0.getTag(R.id.imageLink).toString());
						context.startActivity(intent);
					}
					
					return true;
				}
				
			});
			
			((TextView)convertView.findViewById(R.id.title_text)).setText(title);
			((TextView)convertView.findViewById(R.id.info_text)).setText(info);		
			if(mBitmap != null){
				((ImageView)convertView.findViewById(R.id.image)).setImageBitmap(mBitmap);
			}
			
			convertView.setTag(R.id.mediaLink,mediaLink);
			
			return convertView;	
		}

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public View newView(Context context, Cursor cursor, ViewGroup parent) {
			// TODO Auto-generated method stub
			return null;
		}

}
