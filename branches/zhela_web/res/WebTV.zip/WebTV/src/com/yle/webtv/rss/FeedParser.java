package com.yle.webtv.rss;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.zip.GZIPInputStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;

import com.yle.webtv.service.RssHandleService;

import android.content.Intent;
import android.util.Log;

public class FeedParser {
	private URL feedUrl;
	public static final String NOTIFY_RSS_CHANGED = RssHandleService.class.getName() + ".NOTIFY_RSS_CHANGED";

    //SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();

    public Rss parse() {
        FeedParserHandler handler = new FeedParserHandler();
        //handler.getRss().getmChannels().get(5).getItems().get(2).getLable();
        SAXParserFactory factory = SAXParserFactory.newInstance();
        try {
            SAXParser parser = factory.newSAXParser();
            Log.d("URL", feedUrl.toString());
            parser.parse(this.getInputStream(), handler);
        }
        catch (Exception e) {
        	Log.d("result", "error in parse");
        	e.printStackTrace();
			//throw new RuntimeException(e);
		} 
        return handler.getRss();
    }
    
    public FeedParser(String feedUrl){
		try {
			this.feedUrl = new URL(feedUrl);
		} catch (MalformedURLException e) {
			//throw new RuntimeException(e);
			e.printStackTrace();
		}
	}

	public InputStream getInputStream() {
		Log.d("result", "getInputStream");
		InputStream inputStream = null;
		try {
			inputStream = feedUrl.openConnection().getInputStream();
		} catch (IOException e) {
			//throw new RuntimeException(e);
			e.printStackTrace();
		}
		return inputStream;
	}
}
