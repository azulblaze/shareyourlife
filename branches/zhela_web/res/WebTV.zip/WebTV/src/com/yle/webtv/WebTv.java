package com.yle.webtv;

import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsoluteLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.yle.webtv.net.ConnectionChangeReceiver;
import com.yle.webtv.rss.Channel;
import com.yle.webtv.rss.Rss;
import com.yle.webtv.service.ImagesUpdatingingService;
import com.yle.webtv.service.RssHandleService;
import com.yle.webtv.ui.MainActivity;
import com.yle.webtv.utils.CommonInfo;
import com.yle.webtv.utils.CommonPreference;

public class WebTv extends Activity {
	private ProgressBar pb = null;
	public static WebTv webTvActivity;
	private List<Channel> channels;
	private ContentResolver cr;
	//public static WebTv webtvActivity;
	public static final String RSS_FEED_TYPES = "RSS_FEED_TYPES";
	public static final String RSS_FEED_UPDATING_EXTRA_NAME = "RSS_FEED_UPDATING_EXTRA_NAME";
	public static final int RSS_FEED_UPDATING_EXTRA_FIRST_TIME_VALUE = 10;
	private static final int TYPE_START_MAINACTIVITY_FROM_SERVICE = 0;
	private static final int TYPE_START_MAINACTIVITY_FROM_DATABASE = 1;
	public static final String PREF_NAME = "webtvPreference";
	public static final Rss rssContentSendToMainActivity = new Rss();
	public static final int RSS_FEED_UPDATING_EXTRA_TIMER_VALUE = 1 * 60 * 1000;

	
	/**
	 * here handle how to start the MainActivity class
	 */
	private Handler handler = new Handler() {
		public void handleMessage(Message message) {
			switch (message.what) {
			case TYPE_START_MAINACTIVITY_FROM_SERVICE:
				handler.removeMessages(message.what);
				if (ConnectionChangeReceiver
						.hasGoodEnoughNetworkConnection(WebTv.this)) {
					if (!CommonInfo.isServiceRunning(WebTv.this, "RssHandleService")) {
						Log.d("load", "load from starting new service");
						Intent intent = new Intent(WebTv.this,
								RssHandleService.class);
						intent.putExtra(RSS_FEED_UPDATING_EXTRA_NAME,
								RSS_FEED_UPDATING_EXTRA_FIRST_TIME_VALUE);
						startService(intent);
					} else {
						handler.postDelayed(new Runnable() {
							@Override
							public void run() {
								// TODO Auto-generated method stub
								Log.d("load", "load from DB@@@@@");
								if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.DEFAULT_PREFERENCE_VALUE) {
									channels = Channel.queryChannelsAndItems(cr,
											CommonPreference.TYPE_RSS_FEED_FINNISH);
									if (channels == null || channels.isEmpty()) {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
										handler.sendMessage(message);
									} else {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
										handler.sendMessage(message);
									}
								} else if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.TYPE_RSS_FEED_FINNISH) {
									channels = Channel.queryChannelsAndItems(cr,
											CommonPreference.TYPE_RSS_FEED_FINNISH);
									if (channels == null || channels.isEmpty()) {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
										handler.sendMessage(message);
									} else {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
										handler.sendMessage(message);
									}
								} else if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.TYPE_RSS_FEED_SWEDISH) {
									channels = Channel.queryChannelsAndItems(cr,
											CommonPreference.TYPE_RSS_FEED_SWEDISH);
									if (channels == null || channels.isEmpty()) {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
										handler.sendMessage(message);

									} else {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
										handler.sendMessage(message);
									}
								} else if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST) {
									channels = Channel.queryChannelsAndItems(cr,
											CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST);
									if (channels == null || channels.isEmpty()) {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
										handler.sendMessage(message);

									} else {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
										handler.sendMessage(message);
									}
								} else if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
									channels = Channel.queryChannelsAndItems(cr,
											CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST);
									Log.d("query",
											"loadSwedishPodcastChannelsAndItemsFromDB end  :"
													+ new Date());
									if (channels == null || channels.isEmpty()) {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
										handler.sendMessage(message);

									} else {
										Message message = Message.obtain();
										message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
										handler.sendMessage(message);
									}
								}
							}
							
						}, 5 * 1000);
					}
				}
				break;
			case TYPE_START_MAINACTIVITY_FROM_DATABASE:
				handler.removeMessages(message.what);
				if ((System.currentTimeMillis() - CommonPreference.getSysTimePreference(WebTv.this))
						/ (60 * 1000) > 15) {
					if (ConnectionChangeReceiver
							.hasGoodEnoughNetworkConnection(WebTv.this)) {
						if (!CommonInfo.isServiceRunning(WebTv.this, "RssHandleService")) {
							Intent intent = new Intent(WebTv.this,
									RssHandleService.class);
							intent.putExtra(RSS_FEED_UPDATING_EXTRA_NAME,
									RSS_FEED_UPDATING_EXTRA_TIMER_VALUE);
							startService(intent);
							Log.d("load", "load from DB");
						}
					}
				}

				rssContentSendToMainActivity.setmChannels(channels);
				Intent intent = new Intent(WebTv.this, MainActivity.class);
				Log.d("load", "load from DB");
				webTvActivity.finish();
				startActivity(intent);
				break;
			default:
				break;

			}
		}
	};

	private final BroadcastReceiver serviceReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			if (ConnectionChangeReceiver
					.hasGoodEnoughNetworkConnection(context)) {
				if (!CommonInfo.isServiceRunning(context, "ImagesUpdatingingService")) {
					startService(new Intent(context, ImagesUpdatingingService.class));
				}
			}
			Log.d("query", "loadDefaultChannelsAndItemsFromDB  333333");
			loadDefaultChannelsAndItemsFromDB();
		}
	};
	
	private final BroadcastReceiver connectionServiceReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
//			if (ConnectionChangeReceiver
//					.hasGoodEnoughNetworkConnection(context)) {
//				if (!CommonInfo.isServiceRunning(context, "ImagesUpdatingingService")) {
//					startService(new Intent(context, ImagesUpdatingingService.class));
//				}
//			}
			Log.d("query", "loadDefaultChannelsAndItemsFromDB  33333344444");
			loadDefaultChannelsAndItemsFromDB();
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		cr = getContentResolver();
		super.onCreate(savedInstanceState);
		//webtvActivity = this;

		getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.main);
		pb = (ProgressBar) this.findViewById(R.id.pb);
		
		AbsoluteLayout al = (AbsoluteLayout)this.findViewById(R.id.abslayout);
		int i = CommonPreference.getRssTypePreference(WebTv.this);
		if (i == CommonPreference.TYPE_RSS_FEED_SWEDISH
				|| i == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
			al.setBackgroundResource(R.drawable.swe_background);
		} else {
			al.setBackgroundResource(R.drawable.fi_background);
		}
		
		webTvActivity = this;

		if (!ConnectionChangeReceiver
				.hasGoodEnoughNetworkConnection(WebTv.this)) {
			Toast.makeText(
					this,
					"Attention: There is no network connection right now. The application is working in offline mode.",
					Toast.LENGTH_LONG).show();
		}

		registerReceiver(serviceReceiver, new IntentFilter(
				RssHandleService.NOTIFY_RSS_FEED_COMPLETE));
		
		registerReceiver(connectionServiceReceiver, new IntentFilter(
				RssHandleService.RECEIVER_RSS_FEED_COMPLETE));

		if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.DEFAULT_PREFERENCE_VALUE) {
			Log.d("query", "loadDefaultChannelsAndItemsFromDB  00000");
			loadDefaultChannelsAndItemsFromDB();
		} else if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.TYPE_RSS_FEED_FINNISH) {
			Log.d("query", "loadDefaultChannelsAndItemsFromDB  222222");
			loadDefaultChannelsAndItemsFromDB();
		} else if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.TYPE_RSS_FEED_SWEDISH) {
			loadSwedishChannelsAndItemsFromDB();
		} else if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST) {
			loadDefaultPodcastChannelsAndItemsFromDB();
		} else if (CommonPreference.getRssTypePreference(WebTv.this) == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
			loadSwedishPodcastChannelsAndItemsFromDB();
		}
	}

	public void onStart() {
		super.onStart();
		// setPreferenceForDefaultRssType();
	}

	/**
	 * The default type of channels and items uses finnish language.
	 * 
	 */
	public void loadDefaultChannelsAndItemsFromDB() {
		new Thread() {
			@Override
			public void run() {
				Log.d("query", "loadDefaultChannelsAndItemsFromDB start:"
						+ new Date());
				channels = Channel.queryChannelsAndItems(cr,
						CommonPreference.TYPE_RSS_FEED_FINNISH);
				// channels =
				// RssProvider.operator.loadChannelsAndItems(WebTv.TYPE_RSS_FEED_FINNISH);
				Log.d("query", "loadDefaultChannelsAndItemsFromDB end  :"
						+ new Date());

				if (channels == null || channels.isEmpty()) {
					Message message = Message.obtain();
					message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
					handler.sendMessage(message);

				} else {
					Message message = Message.obtain();
					message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
					handler.sendMessage(message);
				}
			}
		}.start();
	}

	public void loadSwedishChannelsAndItemsFromDB() {
		new Thread() {
			@Override
			public void run() {
				channels = Channel.queryChannelsAndItems(cr,
						CommonPreference.TYPE_RSS_FEED_SWEDISH);
				if (channels == null || channels.isEmpty()) {
					Message message = Message.obtain();
					message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
					handler.sendMessage(message);

				} else {
					Message message = Message.obtain();
					message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
					handler.sendMessage(message);
				}
			}
		}.start();
	}

	public void loadDefaultPodcastChannelsAndItemsFromDB() {
		new Thread() {
			@Override
			public void run() {
				channels = Channel.queryChannelsAndItems(cr,
						CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST);
				if (channels == null || channels.isEmpty()) {
					Message message = Message.obtain();
					message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
					handler.sendMessage(message);

				} else {
					Message message = Message.obtain();
					message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
					handler.sendMessage(message);
				}
			}
		}.start();
	}

	public void loadSwedishPodcastChannelsAndItemsFromDB() {
		new Thread() {
			@Override
			public void run() {
				Log.d("query",
						"loadSwedishPodcastChannelsAndItemsFromDB start:"
								+ new Date());
				channels = Channel.queryChannelsAndItems(cr,
						CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST);
				Log.d("query",
						"loadSwedishPodcastChannelsAndItemsFromDB end  :"
								+ new Date());
				if (channels == null || channels.isEmpty()) {
					Message message = Message.obtain();
					message.what = TYPE_START_MAINACTIVITY_FROM_SERVICE;
					handler.sendMessage(message);

				} else {
					Message message = Message.obtain();
					message.what = TYPE_START_MAINACTIVITY_FROM_DATABASE;
					handler.sendMessage(message);
				}
			}
		}.start();
	}

	public void onResume() {
		super.onResume();
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		unregisterReceiver(serviceReceiver);
		unregisterReceiver(connectionServiceReceiver);
	}
}
