package com.yle.webtv.utils;

import android.app.AlertDialog;
import android.content.Context;

public class CommonUi {
	
	public static void networkStatusDialog(Context context) {
		AlertDialog.Builder alert = new AlertDialog.Builder(context);
		alert.setTitle("Attention:");
		alert.setMessage("There is no network connection right now. Please try again later.");
		alert.create().show();
	}

}
