package com.yle.webtv.rss;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.yle.webtv.rss.Item.Items;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;

public class Channel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4184341578227183636L;
	private String title;
	private List<Item> m_Items;

	private long channeId = 0;
	private int rssType;

	public Channel() {
		setItems(new ArrayList<Item>());
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getChanneId() {
		return channeId;
	}

	public void setChanneId(long channeId) {
		this.channeId = channeId;
	}

	public String getTitle() {
		return title;
	}

	public int getRssType() {
		return rssType;
	}

	public void setRssType(int rssType) {
		this.rssType = rssType;
	}

	public void setItems(List<Item> items) {
		m_Items = items;
	}

	public void addItem(Item item) {
		m_Items.add(item);
	}

	public List<Item> getItems() {
		return m_Items;
	}

	public static void queryOneChannel(Channel channel, Cursor cursor) {
		channel.channeId = cursor.getLong(0) - 1;
		channel.title = cursor.getString(1); // cursor.getString(1);cursor
	}

	public static void insertOneChannel(ContentResolver cr, Channel channel,
			int rssType) {
		ContentValues values = new ContentValues();
		values.put(Channels.TITLE, channel.getTitle());
		values.put(Channels.RSS_TYPE, rssType);
	}

	public static void insertAllChannelsAndItems(ContentResolver cr,
			List<Channel> channels, int rssType) {
		for (int channelSize = 0; channelSize < channels.size(); channelSize++) {
			insertOneChannel(cr, channels.get(channelSize), rssType);
			Item.insertAllItemsForOneChannel(cr, Items.CONTENT_URI, channels
					.get(channelSize).getItems(), channelSize, rssType);
		}
	}

	public static List<Channel> queryChannelsAndItems(ContentResolver cr, int rssFeedType) {
		Cursor cursor = cr.query(Channels.CONTENT_URI, Channels.ALL_CHANNELS,
				Channels.RSS_TYPE + "=?", new String[] { String
						.valueOf(rssFeedType) },
				Channels.ID + " ASC");
		// cursor.moveToFirst();
		List<Channel> channels = new ArrayList<Channel>();
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Channel channel = new Channel();
			Channel.queryOneChannel(channel, cursor);
			// channel.setItems(Item.queryAllItemsOfChannel(cr,
			// channels.size()));
			channel.m_Items = Item.queryAllItemsOfChannel(cr, channels.size(), rssFeedType);
			channels.add(channel);
			cursor.moveToNext();
		}
		cursor.close();
		return channels;
	}

	// public void clean(ContentResolver cr, int keepMaxItems) {
	// // delete old items
	// Cursor cursor = cr.query(Channels.CONTENT_URI,
	// Channels.ALL_CHANNELS, null, null, null);
	//
	// while (cursor.moveToNext()) {
	// long lastPubDate = cursor.getLong(0);
	// cr.delete(Items.CONTENT_URI, Items.CHANNEL_ID + "=? AND " +
	// Items.PUB_DATE + " < ?",
	// new String[] {
	// String.valueOf(this.id),
	// String.valueOf(lastPubDate) });
	// }
	// cursor.close();
	// }

	// public void delete(ContentResolver cr) {
	// cr.delete(Items.CONTENT_URI, Items.CHANNEL_ID + "=?", new String[] {
	// String.valueOf(this.id) });
	// cr.delete(Channels.CONTENT_URI, ContentsProvider.WHERE_ID, new String[] {
	// String.valueOf(this.id) });
	// this.id = 0;
	// }

	public static void deleteAllChannels(ContentResolver cr) {
		Cursor cursor = cr.query(Channels.CONTENT_URI, Channels.ALL_CHANNELS,
				null, null, null);
		if (!cursor.moveToFirst()) {
			cursor.close();
			return;
		}

		while (!cursor.isAfterLast()) {
			cr.delete(Channels.CONTENT_URI, null, null);
			cursor.moveToNext();
		}
		cursor.close();
	}

	public static void deleteAllChannelsAndItems(ContentResolver cr) {
		Channel.deleteAllChannels(cr);
		Item.deleteAllItems(cr);
		Item.deleteAllVirtualItems(cr);
	}

	public static final class Channels implements BaseColumns {
		public static final String CHANNELS_TABLE_NAME = "Channels";
		public static final Uri CONTENT_URI = Uri.parse("content://"
				+ RssProvider.AUTHORITY + "/channels");
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.yle.webtv.channels";

		public static final String ID = "ID";
		public static final String TITLE = "TITLE";
		public static final String RSS_TYPE = "rss_type";
		public static final String[] ALL_CHANNELS = { ID, TITLE, RSS_TYPE };

		private Channels() {
		}
	}
}
