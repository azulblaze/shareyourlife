package com.yle.webtv.ui;

import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ConcurrentHashMap;

import com.yle.webtv.R;
import com.yle.webtv.net.ConnectionChangeReceiver;
import com.yle.webtv.rss.Image;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;

public class ImageCache {
	private static int threadNum = 0;
	private static final int MAX_THREAD_NUM = 5;
	private static byte[] byteArrayBitmap = null;
	private static ConcurrentHashMap<String, SoftReference<Bitmap>> imageCache = new ConcurrentHashMap<String, SoftReference<Bitmap>>();

	public static Bitmap loadImage(final String imageUrl, final int channelId,
			final int itemId, final ImageCallback imageCallback) {
		if (imageCache.containsKey(imageUrl)) {
			SoftReference<Bitmap> softReference = imageCache.get(imageUrl);
			Bitmap bitmap = softReference.get();
			if (bitmap != null) {
				return bitmap;
			}
		}
		
		byteArrayBitmap = Image.queryImageFromUrl(imageUrl, MainActivity.activity.getContentResolver());
		if(byteArrayBitmap !=null){
			
			Bitmap bitmap = BitmapFactory.decodeByteArray(byteArrayBitmap, 0, byteArrayBitmap.length);
			if(bitmap == null){
				bitmap = BitmapFactory.decodeResource(MainActivity.activity.getResources(), R.drawable.default_logo);
			}
			imageCache.put(imageUrl, new SoftReference<Bitmap>(bitmap));
			
			return bitmap;
		}
		
		final Handler handler = new Handler() {
			public void handleMessage(Message message) {
				imageCallback.imageLoaded((Bitmap) message.obj, channelId,
						itemId, imageUrl);
			}
		};
		if (ConnectionChangeReceiver.hasGoodEnoughNetworkConnection(MainActivity.activity)) {
			if(threadNum < MAX_THREAD_NUM){
	
				new Thread() {
					@Override
					public void run() {
						threadNum++;
						Bitmap bitmap;
							bitmap = downloadImageFromUrl(imageUrl);
							
							imageCache.put(imageUrl, new SoftReference<Bitmap>(bitmap));
							threadNum--;
							
							Message message =  Message.obtain();
							message.obj = bitmap;
							message.arg1 = channelId;
							message.arg2 = itemId;
							handler.sendMessage(message);
					}
				}.start();
			}
		}
		return null;
		
	}

	public static boolean containsUrl(String url) {
		return imageCache.containsKey(url);
	}
	
	public interface ImageCallback {
		public void imageLoaded(Bitmap bitmap, final int channelId,
				final int itemId, String imageUrl);
	}

	public static Bitmap downloadImageFromUrl(String imageUrl) {
		
		URL mURL = null;
		try {
			mURL = new URL(imageUrl);
			HttpURLConnection  mHttpURLConnection = (HttpURLConnection) mURL.openConnection();
			mHttpURLConnection.setDoInput(true);
			mHttpURLConnection.connect();

			InputStream in = mHttpURLConnection.getInputStream();
			Bitmap mBitmap = BitmapFactory.decodeStream(in);
			if(mBitmap != null){
				mBitmap = Bitmap.createScaledBitmap(mBitmap, 120, 68, true);
			}else if(mBitmap == null){
				mBitmap = BitmapFactory.decodeResource(MainActivity.activity.getResources(), R.drawable.default_logo);
			}
			return mBitmap;
		} catch (Exception e) {	
			e.printStackTrace();
			return BitmapFactory.decodeResource(MainActivity.activity.getResources(), R.drawable.default_logo);
		}
		
	}

}
