package com.yle.webtv.utils;

import com.yle.webtv.WebTv;

import android.content.Context;
import android.content.SharedPreferences;

public class CommonPreference {
	public static final int DEFAULT_PREFERENCE_VALUE = -1;
	public static final int TYPE_RSS_FEED_FINNISH = 0;
	public static final int TYPE_RSS_FEED_SWEDISH = 1;
	public static final int TYPE_RSS_FEED_FINNISH_PODCAST = 2;
	public static final int TYPE_RSS_FEED_SWEDISH_PODCAST = 3;
	
	private static final String  RSS_FEED_TYPES = "RSS_FEED_TYPES";
	private static final String PREF_NAME = "webtvPreference";
	private static final String RSS_FEED_CURRENT_SYSTEM_TIME = "RSS_FEED_CURRENT_SYSTEM_TIME";
	
	public static void setRssTypePreference(Context context, int rssFeedType) {
		SharedPreferences pref = context.getSharedPreferences(WebTv.PREF_NAME,
				0);
		SharedPreferences.Editor editor = pref.edit();
		editor.putInt(RSS_FEED_TYPES, rssFeedType);
		editor.commit();
	}
	
	public static int getRssTypePreference(Context context) {
		SharedPreferences pref = context.getSharedPreferences(PREF_NAME,
				0);
		int preValue = pref.getInt(RSS_FEED_TYPES, DEFAULT_PREFERENCE_VALUE);
		return preValue;
	}
	
	public static void setSysTimePreference(Context context) {
		SharedPreferences pref = context.getSharedPreferences(PREF_NAME,
				0);
		SharedPreferences.Editor editor = pref.edit();
		editor.putLong(RSS_FEED_CURRENT_SYSTEM_TIME, System.currentTimeMillis());
		editor.commit();
	}
	
	public static long getSysTimePreference(Context context) {
		SharedPreferences pref = context.getSharedPreferences(PREF_NAME,
				0 );
		long preValue = pref.getLong(RSS_FEED_CURRENT_SYSTEM_TIME,
				DEFAULT_PREFERENCE_VALUE);
		return preValue;
	}

}
