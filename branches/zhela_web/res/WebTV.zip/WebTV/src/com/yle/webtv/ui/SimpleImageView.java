package com.yle.webtv.ui;

import android.content.Context;
import android.widget.ImageView;

public class SimpleImageView extends ImageView {

	private String link = null;
	private String imageLink = null;
	
	public String getImageLink() {
		return imageLink;
	}

	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public SimpleImageView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}
}
