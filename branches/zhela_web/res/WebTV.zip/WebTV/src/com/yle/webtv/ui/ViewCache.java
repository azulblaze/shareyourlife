package com.yle.webtv.ui;

import com.yle.webtv.R;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ViewCache {

	    private View baseView;
	    private TextView titleTextView;
	    private TextView infoTextView;
	    private ImageView imageView;
	    private ImageView descriptionView;

	    public ViewCache(View baseView) {
	        this.baseView = baseView;
	    }

	    public TextView getTitleTextView() {
	        if (titleTextView == null) {
	        	titleTextView = (TextView) baseView.findViewById(R.id.title_text);
	        }
	        return titleTextView;
	    }

	    public TextView getInfoTextView() {
	        if (infoTextView == null) {
	        	infoTextView = (TextView) baseView.findViewById(R.id.info_text);
	        }
	        return infoTextView;
	    }
	    
	    public ImageView getImageView() {
	        if (imageView == null) {
	            imageView = (ImageView) baseView.findViewById(R.id.image);
	        }
	        return imageView;
	    }

	    public ImageView getDescriptionView() {
	        if (descriptionView == null) {
	        	descriptionView = (ImageView) baseView.findViewById(R.id.description);
	        }
	        return descriptionView;
	    }
}
