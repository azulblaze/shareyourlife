package com.yle.webtv.ui;

import java.util.List;
import com.yle.webtv.R;
import com.yle.webtv.rss.Rss;
import com.yle.webtv.rss.Item;
import com.yle.webtv.ui.ImageCache.ImageCallback;
import com.yle.webtv.ui.MainActivity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnTouchListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class SimpleArrayAdapter extends ArrayAdapter<Item> {
	MainActivity activity = (MainActivity) getContext();
	private Rss rss = null;
	private int channelId;
	private ListView listView;
	private List<Item> items;

	public SimpleArrayAdapter(Context context, int textViewResourceId,
			List<Item> items, ListView listView, final int channelId) {
		super(context, textViewResourceId, items);
		this.channelId = channelId;
		
		this.listView = listView;
		this.items = items;
		rss = MainActivity.rss;
		//if the index is larger than TAB_INDEX, will add header for them
		if(channelId>=MainActivity.TAB_NUMBER && listView.getAdapter()==null){
			//add header
			TextView header = new TextView(context);
			header.setText(rss.getmChannels().get(channelId).getTitle());
			header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
			header.setTextColor(Color.YELLOW);
			listView.addHeaderView(header);	
		}
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		Bitmap mBitmap = null;
		View rowView = convertView;
		ViewCache viewCache;
	
		if (rowView == null) {
			LayoutInflater inflater = activity.getLayoutInflater();
			rowView = inflater.inflate(R.layout.image_and_text_row, null);
			viewCache = new ViewCache(rowView);
			rowView.setTag(viewCache);
		} else {
			viewCache = (ViewCache) rowView.getTag();
		}

		String mediaLink = items.get(position).getLink();
		ImageView imageView = viewCache.getImageView();
		rowView.setTag(R.id.mediaLink, mediaLink);
		ImageView showDescriptionView = viewCache.getDescriptionView();
		showDescriptionView.setImageResource(R.drawable.expander_default);
		String description = items.get(position).getDescription();
		String title = items.get(position).getTitle();
		String info = items.get(position).getInfo();
		String imageLink = items.get(position).getImage();
		
		showDescriptionView.setTag(R.id.episode_desc,description);
		showDescriptionView.setTag(R.id.episode_info,info);
		showDescriptionView.setTag(R.id.episode_title,title);
		showDescriptionView.setTag(R.id.imageLink,imageLink);
		showDescriptionView.setTag(R.id.mediaLink,mediaLink);
		
		showDescriptionView.setOnTouchListener(new OnTouchListener(){

			@Override
			public boolean onTouch(View arg0, MotionEvent arg1) {
				if (arg1.getAction() == MotionEvent.ACTION_DOWN){
					((ImageView)arg0).setImageResource(R.drawable.expander_pressed);
				}
				if (arg1.getAction() == MotionEvent.ACTION_UP){
					((ImageView)arg0).setImageResource(R.drawable.expander_default);
					Intent intent = new Intent(activity,EpisodeDetails.class);
					intent.putExtra("desc", arg0.getTag(R.id.episode_desc).toString());
					intent.putExtra("info", arg0.getTag(R.id.episode_info).toString());
					intent.putExtra("title", arg0.getTag(R.id.episode_title).toString());
					intent.putExtra("imageLink", arg0.getTag(R.id.imageLink).toString());
					intent.putExtra("mediaLink", arg0.getTag(R.id.mediaLink).toString());
					activity.startActivity(intent);
				}
				return true;
			}
			
		});
		
		mBitmap = ImageCache.loadImage(items.get(position).getImage(), channelId, position,
				new ImageCallback() {

					public void imageLoaded(Bitmap bitmap, final int channelId,
							final int itemId, String imageUrl) {
						ImageView iv = (ImageView) listView
								.findViewWithTag(R.id.mediaLink);
						if (iv != null) {
							if(bitmap != null){
								iv.setImageBitmap(bitmap);
							}
						}
						if(bitmap != null){
							notifyDataSetChanged();
						}
					}
				});
		
		TextView titleTextView = viewCache.getTitleTextView();
		titleTextView.setText(((Item) items.get(position)).getTitle());
		TextView infoTextView = viewCache.getInfoTextView();
		infoTextView.setText(((Item) items.get(position)).getInfo());

		
		if (mBitmap == null) {
			imageView.setImageBitmap(BitmapFactory.decodeResource(MainActivity.activity.getResources(), R.drawable.default_logo));
		} else {
			imageView.setImageBitmap(mBitmap);
		}

		return rowView;
	}
}
