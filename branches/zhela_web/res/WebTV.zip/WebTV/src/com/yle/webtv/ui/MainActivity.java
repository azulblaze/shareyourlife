package com.yle.webtv.ui;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils.TruncateAt;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TableLayout.LayoutParams;

import com.yle.webtv.R;
import com.yle.webtv.WebTv;
import com.yle.webtv.player.VideoPlayer;
import com.yle.webtv.rss.Channel;
import com.yle.webtv.rss.Item;
import com.yle.webtv.rss.Rss;
import com.yle.webtv.search.SearchActivity;
import com.yle.webtv.utils.CommonPreference;

public class MainActivity extends Activity {
	public static MainActivity activity;
	private RelativeLayout mainLayout = null;
	private List<ListView> listViews = new ArrayList<ListView>();
	public static Rss rss = null;
	private String currentLang = "fi";
	private int listview_index = 4;

	// The menu IDs
	private final int MENU_LANGUAGE = R.id.language;
	private final int MENU_AUDIO = R.id.audio;
	private final int MENU_VIDEO = R.id.video;
	private final int MENU_PODCAST = R.id.podcast;
	private final int MENU_SETTINGS = R.id.settings;
	private final int MENU_SEARCH = R.id.search;

	public static final String RSS_FEED_TYPES = "RSS_FEED_TYPES";

	// the number of tabs that will show directly
	public final static int TAB_NUMBER = 5;

	TextView warn_info;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		warn_info = new TextView(this);
		// make the warn_info can't response click event
		warn_info.setOnClickListener(null);
		this.setContentView(R.layout.main_activity_layout);

		ImageView iv_header = (ImageView) this.findViewById(R.id.header);
		int i = CommonPreference.getRssTypePreference(MainActivity.this);
		if (i == CommonPreference.TYPE_RSS_FEED_SWEDISH
				|| i == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
			iv_header.setBackgroundResource(R.drawable.swe_header_logo);
		} else {
			iv_header.setBackgroundResource(R.drawable.fi_header_logo);
		}

		ImageView iv_refresh = (ImageView) this.findViewById(R.id.refresh);
		iv_refresh.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, Transition.class);
				startActivity(i);
			}
		});
		
		activity = this;
		rss = WebTv.rssContentSendToMainActivity;
		List<com.yle.webtv.rss.Channel> channelList = rss.getmChannels();
		// render top buttons
		renderTabs(channelList);
		// add listener for left & right arrows
		addListenerForArrows();
		// add all views to main view
		mainLayout = (RelativeLayout) this.findViewById(R.id.main_activity);
		mainLayout.addView((View) listViews.get(0));
		this.setContentView(mainLayout);
		// setMenuBackground();
	}

	public void initData(List<Channel> channelList) {
		// wrap all the content to ListViews
		for (int i = 0; i < channelList.size(); i++) {
			ListView lv = new ListView(this);
			RelativeLayout.LayoutParams layout = new RelativeLayout.LayoutParams(
					LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
			layout.addRule(RelativeLayout.BELOW, R.id.tabs_container);
			lv.setLayoutParams(layout);

			// set onClick listener for ListViews
			if (i < TAB_NUMBER) {
				lv.setOnItemClickListener(new OnItemClickListener() {
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						String mediaLink = (String) view.getTag(R.id.mediaLink);
						Intent intent = new Intent(MainActivity.this,
								VideoPlayer.class);
						intent.putExtra("uri", mediaLink);
						MainActivity.this.startActivity(intent);
					}
				});
			} else {
				lv.setOnItemClickListener(new OnItemClickListener() {
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						if (position != 0) {
							String mediaLink = (String) view
									.getTag(R.id.mediaLink);
							Intent intent = new Intent(MainActivity.this,
									VideoPlayer.class);
							intent.putExtra("uri", mediaLink);
							MainActivity.this.startActivity(intent);
						}
					}
				});
			}
			// one tab one list item(scrollView) array
			List<com.yle.webtv.rss.Item> listData = ((Channel) channelList
					.get(i)).getItems();

			lv.setTag(R.id.item_list_index, listData);
			lv.setCacheColorHint(0);
			listViews.add((ListView) lv);// all the list views
		}
		// add adapter for the first ListView
		addAdapterForListView(listViews);
	}

	public View renderTabs(List<Channel> channelList) {
		// get the RSS data and enclose them in local variable
		initData(channelList);
		// tab container
		HorizontalScrollView tabs = (HorizontalScrollView) this
				.findViewById(R.id.tabs_container);
		final LinearLayout buttons = (LinearLayout) this
				.findViewById(R.id.tabs);

		// more button list view
		final List<String> moreButtonList = new ArrayList<String>();
		//the more button
		final Button moreButton = new Button(this);
		
		for (int i = 0; i < channelList.size(); i++) {
			Button mButton = new Button(this);
			mButton.setBackgroundColor(0);
			mButton.setTextColor(Color.WHITE);
			mButton.setId(i);
			mButton.setText(((Channel) channelList.get(i)).getTitle());
			mButton.setSingleLine();
			mButton.setEllipsize(TruncateAt.MARQUEE);
			mButton.setFocusable(true);
			mButton.setFocusableInTouchMode(true);
			// set listener on the touch event
			mButton.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					mainLayout.removeViewAt(listview_index);
					mainLayout.addView((View) listViews.get(v.getId()),
							listview_index);
					v.setSelected(true);
					v.requestFocus();
					
					if (listViews.get(v.getId()).getAdapter() == null) {
						List<Item> filtedItem = new ArrayList<Item>();

						List<Item> items = (List<Item>) (listViews.get(v
								.getId())).getTag(R.id.item_list_index);
						for (int j = 0; j < items.size(); j++) {
							Log.i("itemtype", items.get(j).getType());
							if (CommonPreference
									.getRssTypePreference(MainActivity.this) == CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST
									|| CommonPreference
											.getRssTypePreference(MainActivity.this) == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
								if (items.get(j).getType().equals("audio")) {
									filtedItem.add(items.get(j));
								}
							} else {
								if (items.get(j).getType().equals("video")) {
									filtedItem.add(items.get(j));
								}
							}
						}
						SimpleArrayAdapter mSimpleArrayAdapter = new SimpleArrayAdapter(
								MainActivity.this, new TextView(
										MainActivity.this).getId(), filtedItem,
								listViews.get(v.getId()), v.getId());
						// if there is no content in ListView
						setIfNoContent(mSimpleArrayAdapter,
								listViews.get(v.getId()));
						listViews.get(v.getId())
								.setAdapter(mSimpleArrayAdapter);
					}
					return true;
				}
			});

			mButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					mainLayout.removeViewAt(listview_index);
					mainLayout.addView((View) listViews.get(v.getId()),
							listview_index);
					v.setSelected(true);
					
					if(!v.isFocused()){
						v.requestFocus();
					}
				
					if (listViews.get(v.getId()).getAdapter() == null) {
						List<Item> filtedItem = new ArrayList<Item>();

						List<Item> items = (List<Item>) (listViews.get(v
								.getId())).getTag(R.id.item_list_index);
						for (int j = 0; j < items.size(); j++) {
							Log.i("itemtype", items.get(j).getType());
							if (CommonPreference
									.getRssTypePreference(MainActivity.this) == CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST
									|| CommonPreference
											.getRssTypePreference(MainActivity.this) == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
								if (items.get(j).getType().equals("audio")) {
									filtedItem.add(items.get(j));
								}
							} else {
								if (items.get(j).getType().equals("video")) {
									filtedItem.add(items.get(j));
								}
							}
						}
						SimpleArrayAdapter mSimpleArrayAdapter = new SimpleArrayAdapter(
								MainActivity.this, new TextView(
										MainActivity.this).getId(), filtedItem,
								listViews.get(v.getId()), v.getId());

						// if there is no content in ListView
						setIfNoContent(mSimpleArrayAdapter,
								listViews.get(v.getId()));

						listViews.get(v.getId())
								.setAdapter(mSimpleArrayAdapter);
					}
				}
			});
			//what to do when the focus changed
			mButton.setOnFocusChangeListener(new OnFocusChangeListener(){
				@Override
				public void onFocusChange(View v, boolean hasFocus) {
					// TODO Auto-generated method stub
					if(hasFocus){
						v.setBackgroundResource(R.drawable.navigation_selected_item);
//						v.performClick();
					} else {
						v.setBackgroundColor(0);
					}
				}
			});
			
			mButton.setLayoutParams(new LinearLayout.LayoutParams(100, 48));
			if (i < TAB_NUMBER) {
				buttons.addView(mButton);
			} else {
				moreButtonList.add(((Channel) channelList.get(i)).getTitle());
			}
			// focus the first tab
			((Button) buttons.getChildAt(0)).requestFocus();
		}

		final ListView moreButtonListView = new ListView(this);
		moreButtonListView.setCacheColorHint(0);
		RelativeLayout.LayoutParams layout = new RelativeLayout.LayoutParams(
				LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		layout.addRule(RelativeLayout.BELOW, R.id.tabs_container);
		moreButtonListView.setLayoutParams(layout);

		moreButtonListView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {

				mainLayout.removeViewAt(listview_index);
				mainLayout.addView(listViews.get(arg2 + TAB_NUMBER),
						listview_index);

				if (listViews.get(arg2 + TAB_NUMBER).getAdapter() == null) {
					List<Item> filtedItem = new ArrayList<Item>();

					List<Item> items = (List<Item>) (listViews.get(arg2
							+ TAB_NUMBER)).getTag(R.id.item_list_index);
					for (int j = 0; j < items.size(); j++) {
						Log.i("itemtype", items.get(j).getType());
						if (CommonPreference
								.getRssTypePreference(MainActivity.this) == CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST
								|| CommonPreference
										.getRssTypePreference(MainActivity.this) == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
							if (items.get(j).getType().equals("audio")) {
								filtedItem.add(items.get(j));
							}
						} else {
							if (items.get(j).getType().equals("video")) {
								filtedItem.add(items.get(j));
							}
						}
					}

					SimpleArrayAdapter mSimpleArrayAdapter = new SimpleArrayAdapter(
							MainActivity.this, new TextView(MainActivity.this)
									.getId(), filtedItem, listViews.get(arg2
									+ TAB_NUMBER), arg2 + TAB_NUMBER);

					listViews.get(arg2 + TAB_NUMBER).setAdapter(
							mSimpleArrayAdapter);
				}
				// focus the list View
				listViews.get(arg2 + TAB_NUMBER).setFocusable(true);
				listViews.get(arg2 + TAB_NUMBER).setFocusableInTouchMode(true);
				listViews.get(arg2 + TAB_NUMBER).requestFocus();
			}
		});

		moreButton.setBackgroundColor(0);
		moreButton.setTextColor(Color.WHITE);
		moreButton.setLayoutParams(new LinearLayout.LayoutParams(100, 48));
		moreButton.setFocusable(true);
		moreButton.setFocusableInTouchMode(true);
		if (CommonPreference.getRssTypePreference(MainActivity.this) == 1
				|| CommonPreference.getRssTypePreference(MainActivity.this) == 3) {
			moreButton.setText(R.string.swe_str_more);
		} else {
			moreButton.setText(R.string.fi_str_more);
		}

		// set listener on the touch event
		moreButton.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()){
				case MotionEvent.ACTION_UP:
					v.setFocusable(true);
					v.setFocusableInTouchMode(true);
					v.requestFocus();
					mainLayout.removeViewAt(listview_index);
					mainLayout.addView(moreButtonListView, listview_index);
					ArrayAdapter adapter = new ArrayAdapter(MainActivity.this,
							R.layout.notes_row, moreButtonList);
					// if there is no content, there will show a string
					// "there is no content"
					setIfNoContent(adapter, moreButtonListView);
					moreButtonListView.setAdapter(adapter);
					break;
				default:
					return false;
				}
				return true;
			}
		});

		moreButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mainLayout.removeViewAt(listview_index);
				mainLayout.addView(moreButtonListView, listview_index);

				ArrayAdapter adapter = new ArrayAdapter(MainActivity.this,
						R.layout.notes_row, moreButtonList);
				// if there is no content, there will show a string
				// "there is no content"
				setIfNoContent(adapter, moreButtonListView);
				moreButtonListView.setAdapter(adapter);
			}
		});
		
		moreButton.setOnFocusChangeListener(new OnFocusChangeListener(){
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if(hasFocus){
					v.setBackgroundResource(R.drawable.navigation_selected_item);
//					v.performClick();
				}else {
					v.setBackgroundColor(0);
				}
			}
		});
		// add the more button to tabs
		buttons.addView(moreButton);
		return tabs;
	}

	private void addAdapterForListView(List<ListView> listViews) {
		List<Item> filtedItem = new ArrayList<Item>();

		List<Item> items = (List<Item>) listViews.get(0).getTag(
				R.id.item_list_index);
		for (int j = 0; j < items.size(); j++) {
			Log.i("itemtype", items.get(j).getType());
			if (CommonPreference.getRssTypePreference(MainActivity.this) == CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST
					|| CommonPreference.getRssTypePreference(MainActivity.this) == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
				if (items.get(j).getType().equals("audio")) {
					filtedItem.add(items.get(j));
				}

			} else {
				if (items.get(j).getType().equals("video")) {
					filtedItem.add(items.get(j));
				}
			}
		}
		SimpleArrayAdapter mSimpleArrayAdapter = new SimpleArrayAdapter(this,
				new TextView(this).getId(), filtedItem, listViews.get(0), 0);

		listViews.get(0).setAdapter(mSimpleArrayAdapter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		MenuInflater inflater = this.getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		setCurrentLanguage(CommonPreference
				.getRssTypePreference(MainActivity.this));
		if (currentLang.equals("fi")) {
			menu.findItem(MENU_LANGUAGE).setTitle(R.string.fi_str_swedish);
			menu.findItem(MENU_VIDEO).setTitle(R.string.fi_str_video);
			menu.findItem(MENU_AUDIO).setTitle(R.string.fi_str_audio);
			if (CommonPreference.getRssTypePreference(this) == 0
					|| CommonPreference.getRssTypePreference(this) == 1) {
				menu.findItem(MENU_PODCAST).setTitle(R.string.fi_str_podcast);
			} else if (CommonPreference.getRssTypePreference(this) == 2
					|| CommonPreference.getRssTypePreference(this) == 3) {
				menu.findItem(MENU_PODCAST).setTitle(R.string.fi_str_rss);
				menu.findItem(MENU_VIDEO).setEnabled(false);
				menu.findItem(MENU_AUDIO).setEnabled(false);
			} else {
				menu.findItem(MENU_PODCAST).setTitle(R.string.fi_str_podcast);
			}
			menu.findItem(MENU_SETTINGS).setTitle(R.string.fi_str_settings);
		} else if (currentLang.equals("swe")) {
			menu.findItem(MENU_LANGUAGE).setTitle(R.string.swe_str_finish);
			menu.findItem(MENU_VIDEO).setTitle(R.string.swe_str_video);
			menu.findItem(MENU_AUDIO).setTitle(R.string.swe_str_audio);
			if (CommonPreference.getRssTypePreference(this) == 0
					|| CommonPreference.getRssTypePreference(this) == 1) {
				menu.findItem(MENU_PODCAST).setTitle(R.string.swe_str_podcast);
			} else if (CommonPreference.getRssTypePreference(this) == 2
					|| CommonPreference.getRssTypePreference(this) == 3) {
				menu.findItem(MENU_PODCAST).setTitle(R.string.swe_str_rss);
				menu.findItem(MENU_VIDEO).setEnabled(false);
				menu.findItem(MENU_AUDIO).setEnabled(false);
			} else {
				menu.findItem(MENU_PODCAST).setTitle(R.string.swe_str_podcast);
			}
			menu.findItem(MENU_SETTINGS).setTitle(R.string.swe_str_settings);
		}
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case MENU_SEARCH:
			Intent intent = new Intent(this, SearchActivity.class);
			intent.setAction(Intent.ACTION_SEARCH);
			this.startActivity(intent);

			break;

		case MENU_LANGUAGE:
			if (currentLang.equals("fi")) {
				currentLang = "swe";

			} else if (currentLang.equals("swe")) {
				currentLang = "fi";
			}
			switchToRelatedLanguage(CommonPreference
					.getRssTypePreference(MainActivity.this));
			break;
		case MENU_AUDIO:
			appendFilter("audio");
			break;
		case MENU_VIDEO:
			appendFilter("video");
			break;
		case MENU_PODCAST:
			switchToRelatedPodcast(CommonPreference
					.getRssTypePreference(MainActivity.this));
			break;
		case MENU_SETTINGS:
			openInfo();
			break;

		}
		return true;
	}

	public void appendFilter(String type) {

		for (int i = 0; i < listViews.size(); i++) {
			List<Item> filtedItem = new ArrayList<Item>();

			List<Item> items = (List<Item>) listViews.get(i).getTag(
					R.id.item_list_index);
			for (int j = 0; j < items.size(); j++) {
				Log.i("itemtype", items.get(j).getType());
				if (items.get(j).getType().equals(type)) {
					filtedItem.add(items.get(j));
				}
			}
			SimpleArrayAdapter adapter = new SimpleArrayAdapter(this,
					new TextView(this).getId(), filtedItem,
					(ListView) listViews.get(i), i);
			Log.i("currentLang", currentLang);
			setIfNoContent(adapter, listViews.get(i));
			listViews.get(i).setAdapter(adapter);
		}
	}

	public void openInfo() {
		Intent i = new Intent(this, SettingsActivity.class);
		i.putExtra("currentLang", currentLang);
		this.startActivity(i);
	}

	public void switchToRelatedLanguage(int languageType) {
		Log.d("BBB", Integer.toString(languageType)
				+ " switchToRelatedLanguage");

		Intent intent = new Intent(this, WebTv.class);
		switch (languageType) {
		case CommonPreference.TYPE_RSS_FEED_FINNISH:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_SWEDISH);
			currentLang = "swe";
			startActivity(intent);
			break;
		case CommonPreference.TYPE_RSS_FEED_SWEDISH:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_FINNISH);
			currentLang = "fi";
			startActivity(intent);
			break;

		case CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST);
			currentLang = "swe";
			startActivity(intent);
			break;

		case CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST);
			currentLang = "fi";
			startActivity(intent);
			break;

		default:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_SWEDISH);
			currentLang = "swe";
			startActivity(intent);
			break;
		}
		this.finish();
	}

	public void setCurrentLanguage(int languageType) {
		switch (languageType) {
		case CommonPreference.TYPE_RSS_FEED_FINNISH:
			currentLang = "fi";
			break;
		case CommonPreference.TYPE_RSS_FEED_SWEDISH:
			currentLang = "swe";
			break;

		case CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST:
			currentLang = "fi";
			break;

		case CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST:
			currentLang = "swe";
			break;

		default:
			currentLang = "fi";
			break;
		}
	}

	public void switchToRelatedPodcast(int languageType) {
		Intent intent = new Intent(this, WebTv.class);
		Log.d("BBB", Integer.toString(languageType) + " switchToRelatedPodcast");
		switch (languageType) {
		case CommonPreference.TYPE_RSS_FEED_FINNISH:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST);
			currentLang = "fi";
			startActivity(intent);
			break;
		case CommonPreference.TYPE_RSS_FEED_SWEDISH:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST);
			currentLang = "swe";
			startActivity(intent);
			break;

		case CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_FINNISH);
			currentLang = "fi";
			startActivity(intent);
			break;
		case CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_SWEDISH);
			currentLang = "swe";
			startActivity(intent);
			break;

		default:
			CommonPreference.setRssTypePreference(this,
					CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST);
			currentLang = "fi";
			startActivity(intent);
			break;
		}
		this.finish();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	
	public void setIfNoContent(Adapter adapter,ListView lv){
		if(adapter.isEmpty()){
			if(CommonPreference.getRssTypePreference(this) ==CommonPreference.TYPE_RSS_FEED_FINNISH || CommonPreference.getRssTypePreference(this) ==CommonPreference.TYPE_RSS_FEED_FINNISH_PODCAST ){
				warn_info.setText(R.string.fi_no_content);
			} else if (CommonPreference.getRssTypePreference(this) == CommonPreference.TYPE_RSS_FEED_SWEDISH
					|| CommonPreference.getRssTypePreference(this) == CommonPreference.TYPE_RSS_FEED_SWEDISH_PODCAST) {
				warn_info.setText(R.string.swe_no_content);
			}
			if (lv.getFooterViewsCount() == 0) {
				lv.addFooterView(warn_info);
			}
		} else {
			lv.removeFooterView(warn_info);
		}
	}

	public void addListenerForArrows() {
		final ImageView leftArrow = (ImageView)this.findViewById(R.id.left_arrow);
		final ImageView rightArrow = (ImageView)this.findViewById(R.id.right_arrow);
		final HorizontalScrollView tabs = (HorizontalScrollView)this.findViewById(R.id.tabs_container);
		RelativeLayout  leftArrowContainer = (RelativeLayout)this.findViewById(R.id.navigation_arrow_left_container);
		RelativeLayout  rightArrowContainer = (RelativeLayout)this.findViewById(R.id.navigation_arrow_right_container);

		try {
			final Method method = tabs.getClass().getDeclaredMethod(
					"computeHorizontalScrollRange", null);
			method.setAccessible(true);
			tabs.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View arg0, MotionEvent arg1) {
					// TODO Auto-generated method stub

			    	try {
						final Integer all_scroll = (Integer)method.invoke(tabs, null);
						if(arg1.getAction() == MotionEvent.ACTION_UP ){
							Log.i("getScrollX",Integer.toString(tabs.getScrollX()));
							Log.i("all_scroll",Integer.toString(all_scroll));
							if(tabs.getScrollX()==0){
								leftArrow.setImageResource(R.drawable.navigation_arrow_left_disable);
							}else if(tabs.getScrollX()+arg0.getWidth()-10==all_scroll.intValue()){
								rightArrow.setImageResource(R.drawable.navigation_arrow_right_disable);
							}else{
								leftArrow.setImageResource(R.drawable.navigation_arrow_left);
								rightArrow.setImageResource(R.drawable.navigation_arrow_right);
							}
							return false;
						}
			    	}catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return false;
				}
			});
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		leftArrowContainer.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				tabs.fullScroll(View.FOCUS_LEFT);
				MainActivity.this.getCurrentFocus().performClick();
				leftArrow.setImageResource(R.drawable.navigation_arrow_left_disable);
				rightArrow.setImageResource(R.drawable.navigation_arrow_right);
				return true;
			}
		});

		rightArrowContainer.setOnTouchListener(new OnTouchListener(){
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				tabs.fullScroll(View.FOCUS_RIGHT);
				MainActivity.this.getCurrentFocus().performClick();
				rightArrow.setImageResource(R.drawable.navigation_arrow_right_disable);
				leftArrow.setImageResource(R.drawable.navigation_arrow_left);
				return true;
			}
		});
		}
	}
	
//	protected void setMenuBackground() {
//		getLayoutInflater().setFactory(new Factory() {
//
//			@Override
//			public View onCreateView(String name, Context context,
//					AttributeSet attrs) {
//				if (name.equalsIgnoreCase("com.android.internal.view.menu.IconMenuItemView")) {
//
//					try { // Ask our inflater to create the view
//						LayoutInflater f = getLayoutInflater();
//						final View view = f.createView(name, null, attrs);
//						// Kind of apply our own background
//						new Handler().post(new Runnable() {
//							public void run() {
//								view.setBackgroundResource(R.drawable.menu_bg);
//							}
//						});
//						return view;
//					} catch (InflateException e) {
//					} catch (ClassNotFoundException e) {
//
//					}
//				}
//				return null;
//			}
//		});
//	}
		
