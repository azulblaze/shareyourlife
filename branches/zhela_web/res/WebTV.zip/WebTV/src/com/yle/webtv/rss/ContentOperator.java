package com.yle.webtv.rss;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.yle.webtv.rss.Channel.Channels;
import com.yle.webtv.rss.Image.Images;
import com.yle.webtv.rss.Item.Items;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;


public class ContentOperator {

    private static final String TAG = "delete";
	private SQLiteDatabase db = null;
    private DatabaseOpenHelper helper = null;

    public ContentOperator(Context context) {
        helper = new DatabaseOpenHelper(context);
        db = helper.getWritableDatabase();
        db.setLockingEnabled(true);
    }

    public synchronized void close() {
        db.close();
        helper.close();
    }

    public SQLiteDatabase getCurrentDb() {
        return db;
    }

//    public List<Channel> queryChannels() {
//        Cursor cursor = null;
//        try {
//            cursor = db.query(Channels.CHANNELS_TABLE_NAME, Channels.ALL_CHANNELS, null, null, null, null, Channels.TITLE);
//            int size = cursor.getCount();
//            if (size==0)
//                return Collections.emptyList();
//            cursor.moveToFirst();
//            List<Channel> list = new ArrayList<Channel>(size);
//            while (!cursor.isAfterLast()) {
//            	list.add(mappingChannels(cursor));
//                cursor.moveToNext();
//            }
//            return list;
//        }
//        finally {
//            close(cursor);
//        }
//    }
//
//    public List<Item> queryItems() {
//        Cursor cursor = null;
//        try {
//            cursor = db.query(Items.ITEMS_TABLE_NAME, Items.ALL_ITEMS, null, null, null, null, Items.TITLE);
//            int size = cursor.getCount();
//            if (size==0)
//                return Collections.emptyList();
//            cursor.moveToFirst();
//            List<Item> list = new ArrayList<Item>(size);
//            while (!cursor.isAfterLast()) {
//            	list.add(mappingItems(cursor));
//                cursor.moveToNext();
//            }
//            return list;
//        }
//        finally {
//            close(cursor);
//        }
//    }
//
//    Channel mappingChannels(Cursor cursor) {
//    	Channel channel = new Channel();
//        String title = cursor.getString(2);
//        channel.setTitle(title);
//        
//        return channel;
//    }
//
//    Item mappingItems(Cursor cursor) {
//    	Item item = new Item();
//    	
//    	int channelId = cursor.getInt(2);
//    	item.setChannelId(channelId);
//    	
//        String title = cursor.getString(3);
//        item.setTitle(title);
//        
//        String type = cursor.getString(4);
//        item.setType(type);
//        
//        String description = cursor.getString(5);
//        item.setDescription(description);
//        
//        String info = cursor.getString(6);
//        item.setInfo(info);
//        
//        String image = cursor.getString(7);
//        item.setImage(image);
//        
//        String link = cursor.getString(8);
//        item.setLink(link);
//        
//        String miniview = cursor.getString(9);
//        item.setMiniview(miniview);
//        
//        String label = cursor.getString(9);
//        item.setLable(label);
//        
//        return item;
//    }
//    
//    public void close(Cursor cursor) {
//        if (cursor!=null)
//            cursor.close();
//    }
//
//
//    public long insertChannels(Channel channel) {
//        ContentValues cv = new ContentValues();
//        cv.put(Channels.ID, Channels.ID);
//        cv.put(Channels.TITLE, channel.getTitle());
//        return db.insert(Channels.CHANNELS_TABLE_NAME, null, cv);
//    }
//
//    public long insertItems(Item item) {
//        ContentValues cv = new ContentValues();
//        cv.put(Items.ID, Items.ID);
//        cv.put(Items.CHANNEL_ID, item.getChannelId());
//        cv.put(Items.TITLE, item.getTitle());
//        cv.put(Items.TYPE, item.getType());
//        cv.put(Items.DESCRIPTION, item.getDescription());
//        cv.put(Items.INFO, item.getInfo());
//        cv.put(Items.IMAGE, item.getImage());
//        cv.put(Items.LINK, item.getLink());
//        cv.put(Items.MINIVIEW, item.getMiniview());
//        cv.put(Items.LABEL, item.getLable());
//        
//        return db.insert(Items.ITEMS_TABLE_NAME, null, cv);
//    }
    
    public void clearBothChannelAndItemTable() {
    	db.delete(Channels.CHANNELS_TABLE_NAME, null, null);
    	//db.delete(Items.ITEMS_TABLE_NAME, null, null);
    	db.delete(Items.ITEMS_VIRTUAL_TABLE_NAME, null, null);
    	db.delete(Images.IMAGES_TABLE_NAME, null, null);
    }
    
    public void saveBothChannelsAndItems(List<Channel> channels, int rssFeedType) {
		db.beginTransaction();
		try {
			Log.d(TAG, "delete channel start  " + new Date());
			Log.d(TAG, "delete channel end  " + new Date());
			for (Channel channel : channels) {
				db.execSQL("insert into " + Channels.CHANNELS_TABLE_NAME + "("
						+ Channels.TITLE + ", " 
						+ Channels.RSS_TYPE
						+ ")" + " values(?, ?)",
						new Object[] { channel.getTitle(),  rssFeedType});
			}

			//Log.d(TAG, "delete channel start  " + new Date());
			
			//Log.d(TAG, "delete channel end  " + new Date());
			
			
			for (int channelSize = 0; channelSize < channels.size(); channelSize++) {
				for (int itemSize = 0; itemSize < channels.get(channelSize)
						.getItems().size(); itemSize++) {
					db.execSQL(
							"insert into VirtualItems(item_id , channel_id , " 
							+ "item_title, item_type, "
							+ "item_description, item_info, image_url, " 
							+ "media_link, item_miniview, "
							+ "item_label, rss_type) values(?,?,?,?,?,?,?,?,?,?, ?)",
							new Object[] {
									itemSize,
									channelSize,
									channels.get(channelSize).getItems()
											.get(itemSize).getTitle(),
									channels.get(channelSize).getItems()
											.get(itemSize).getType(),
									channels.get(channelSize).getItems()
											.get(itemSize).getDescription(),
									channels.get(channelSize).getItems()
											.get(itemSize).getInfo(),
									channels.get(channelSize).getItems()
											.get(itemSize).getImage(),
									channels.get(channelSize).getItems()
											.get(itemSize).getLink(),
									channels.get(channelSize).getItems()
											.get(itemSize).getMiniview(),
									channels.get(channelSize).getItems()
											.get(itemSize).getLable(),
									rssFeedType});
				}
			}
			Log.d(TAG, "insert item end  " + new Date());
			db.setTransactionSuccessful();
		} finally {
			db.endTransaction();
		}
		//db.close();
	}
    
    public void saveImagesInformation(List<Channel> channels) {
		db.beginTransaction();
		try {
			Log.d(TAG, "save inmage info start  " + new Date());
			
			for (int channelSize = 0; channelSize < channels.size(); channelSize++) {
				for (int itemSize = 0; itemSize < channels.get(channelSize)
						.getItems().size(); itemSize++) {
					db.execSQL("insert into " + Images.IMAGES_TABLE_NAME + "("
							+ Images.URL + ", " 
							+ Images.STATUS + ","
							+ Images.IMAGE_CONTENT
							+ ")" + " values(?, ?, ?)",
							new Object[] { channels.get(channelSize).getItems()
							.get(itemSize).getImage(),  Image.IMAGE_STATUS_QUEUED, null});
				}
			}
			Log.d(TAG, "insert item end  " + new Date());
			db.setTransactionSuccessful();
		} finally {
			db.endTransaction();
		}
		//db.close();
	}
    
    public  List<Item> loadItemsFromDB(
			int channelId, int rssFeedType) {
		Cursor cursor = db.query(Items.ITEMS_TABLE_NAME, Items.ALL_ITEMS,
				Items.CHANNEL_ID + "=?" +" AND " + Items.RSS_TYPE + "=?",
				new String[] { String.valueOf(channelId),  String.valueOf(rssFeedType)}, null, null,Items.ID + " ASC");

		// List<Item> oldItems = channel.getItems();
		// oldItems.clear();
		cursor.moveToFirst();
		List<Item> items = new ArrayList<Item>();
		while (!cursor.isAfterLast()) {
			Item item = new Item();
			item.setId(cursor.getLong(0));
			item.setItemId(cursor.getLong(1)) ;
			item.setChannelId(cursor.getLong(2)) ;
			item.setTitle(cursor.getString(3));
			item.setType(cursor.getString(4));
			item.setDescription(cursor.getString(5));
			item.setInfo(cursor.getString(6));
			item.setImage(cursor.getString(7));
			item.setLink(cursor.getString(8));
			item.setMiniview(cursor.getString(9));
			item.setLable(cursor.getString(10));
			//queryItem(item, cursor);
			items.add(item);
			cursor.moveToNext();
		}
		cursor.close();
		return items;
	}

    public List<Channel> loadChannelsAndItems(int rssFeedType) {
        List<Channel> list = new ArrayList<Channel>();
        Cursor cursor = db.query(Channels.CHANNELS_TABLE_NAME, Channels.ALL_CHANNELS , 
        		Channels.RSS_TYPE + "=?", new String[] { String
				.valueOf(rssFeedType) }, null, null, Channels.ID + " ASC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
            	Channel channel = new Channel();
            	channel.setChanneId(cursor.getLong(0) - 1) ;
        		channel.setTitle(cursor.getString(1));
        		channel.setItems(loadItemsFromDB(list.size(), rssFeedType));
                list.add(channel); 
            } while (cursor.moveToNext());
        }
        
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        return list;
    }
    
}

