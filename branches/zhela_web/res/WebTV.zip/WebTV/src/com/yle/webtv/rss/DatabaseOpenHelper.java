package com.yle.webtv.rss;

import com.yle.webtv.rss.Channel.Channels;
import com.yle.webtv.rss.Image.Images;
import com.yle.webtv.rss.Item.Items;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseOpenHelper extends SQLiteOpenHelper {
	private static final String DATABASE_NAME = "yleareena.db";
	private static final String CHANNELS_TABLE_NAME = "Channels";
	private static final String ITEMS_TABLE_NAME = "Items";
	private static final String ITEMS_VIRTUAL_TABLE_NAME = "VirtualItems";
	private static final String IMAGES_TABLE_NAME = "Images";
	private static final int DATABASE_VERSION = 1;

	public DatabaseOpenHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		String sqlCreateChannels = "CREATE TABLE "
				+ CHANNELS_TABLE_NAME + " (" 
				+ Channels.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+ Channels.TITLE + " VARCHAR(256), " 
				+ Channels.RSS_TYPE + " INTEGER" 
				+ ");";

		String sqlCreateItems = "CREATE TABLE " 
				+ ITEMS_TABLE_NAME +"("
				//+ "  USING FTS3 ("
				+ Items.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
				+
				Items.ITEM_ID + " INTEGER, " +
				Items.CHANNEL_ID + " INTEGER, " 
				+ Items.TITLE + " VARCHAR(256), "
				+ Items.TYPE + " VARCHAR(256), "
				+
				// Items.LANGUAGE_TYPE + " VARCHAR(32), " +
				Items.DESCRIPTION + " TEXT, " 
				+ Items.INFO + " VARCHAR(256), "
				+ Items.IMAGE + " VARCHAR(1024), " 
				+ Items.LINK + " VARCHAR(1024), " 
				+ Items.MINIVIEW + " VARCHAR(8), "
				+ Items.LABEL + " VARCHAR(256), " 
				+ Items.RSS_TYPE + " INTEGER" 
				+ ");";
		
		String sqlCreateVirtualItems = "CREATE VIRTUAL TABLE " 
			+ ITEMS_VIRTUAL_TABLE_NAME 
			+ "  USING FTS3 ("
			+ Items.ITEM_ID + " INTEGER, " 
			+ Items.CHANNEL_ID + " INTEGER, " 
			+ Items.TITLE + " VARCHAR(256), "
			+ Items.TYPE + " VARCHAR(256), "
			+ Items.DESCRIPTION + " TEXT, " 
			+ Items.INFO + " VARCHAR(256), "
			+ Items.IMAGE + " VARCHAR(1024), " 
			+ Items.LINK + " VARCHAR(1024), " 
			+ Items.MINIVIEW + " VARCHAR(8), "
			+ Items.LABEL + " VARCHAR(256), " 
			+ Items.RSS_TYPE + " INTEGER"
			+ ");";
		
		String sqlCreateImages = "CREATE TABLE " 
			+ IMAGES_TABLE_NAME 
			+ "("
			+Images.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " 
			+Images.URL + " VARCHAR(1024),"
			+Images.STATUS + " INTEGER, "
			+Images.IMAGE_CONTENT + " BOLB"
			+");";

		db.execSQL(sqlCreateChannels);
		//db.execSQL(sqlCreateItems);
		db.execSQL(sqlCreateVirtualItems);
		db.execSQL(sqlCreateImages);
		
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "ItemIdIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.ITEM_ID + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "ChannelIdIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.CHANNEL_ID + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "TitleIdIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.TITLE + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "TypeIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.TYPE + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "DescriptionIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.DESCRIPTION + ");");
//		
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "InfoIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.INFO + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "ImageIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.IMAGE + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "LinkIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.LINK + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "MiniviewIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.MINIVIEW + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "LabelIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.LABEL + ");");
//		db.execSQL("CREATE INDEX IF NOT EXISTS " + ITEMS_TABLE_NAME
//                + "RssTypeIndex ON " +  ITEMS_TABLE_NAME +" (" + Items.RSS_TYPE + ");");
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		if (oldVersion != newVersion) {
			db.execSQL("DROP TABLE IF EXISTS " + CHANNELS_TABLE_NAME);
			db.execSQL("DROP TABLE IF EXISTS " + ITEMS_TABLE_NAME);
			db.execSQL("DROP TABLE IF EXISTS " + IMAGES_TABLE_NAME);
			onCreate(db);
		}
	}

}
