package com.yle.webtv.rss;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

public class FeedParserHandler extends DefaultHandler {

	private final String[] str = { "rss",
			"channel", "title", "item", "type", "description", "info", "image",
			"link", "miniview", "label" };

	private Channel channel;
	private Item item = null;
	private Rss rss;
	private StringBuilder text;

	public Rss getRss() {
		return this.rss;
	}

	@Override
	public void characters(char ch[], int start, int length) {
		this.text.append(ch, start, length);
	}

	@Override
	public void endElement(String namespaceURI, String localName, String qName)
			throws SAXException {

		if (this.rss == null) {
			return;
		}

		if (localName.equalsIgnoreCase(this.str[2])) {
			if (this.item != null) {
				this.item.setTitle(this.text.toString().trim());
			} else {
				this.channel.setTitle(this.text.toString().trim());
			}
		}

		if (localName.equalsIgnoreCase(this.str[3])) {
			this.item = null;
		}

		if (localName.equalsIgnoreCase(this.str[4])) {
			this.item.setType(this.text.toString().trim());

		}

		if (localName.equalsIgnoreCase(this.str[5])) {
			this.item.setDescription(this.text.toString().trim());
		}

		if (localName.equalsIgnoreCase(this.str[6])) {
			this.item.setInfo(this.text.toString().trim());
		}

		if (localName.equalsIgnoreCase(this.str[7])) {
			this.item.setImage(this.text.toString().trim());
		}

		if (localName.equalsIgnoreCase(this.str[8])) {
			this.item.setLink(this.text.toString().trim());
		}

		if (localName.equalsIgnoreCase(this.str[9])) {
			this.item.setMiniview(this.text.toString().trim());
		}

		if (localName.equalsIgnoreCase(this.str[10])) {
			this.item.setLable(this.text.toString().trim());
		}

		this.text.setLength(0);

	}

	@Override
	public void startElement(String namespaceURI, String localName,
			String qName, Attributes atts) throws SAXException {
		
		//Log.d("start", localName);
		if (localName.equalsIgnoreCase(this.str[0])) {
			this.rss = new Rss();
		}

		if (localName.equalsIgnoreCase(this.str[1]) && (this.rss != null)) {
			//Log.d("channel", "channel");
			this.channel = new Channel();
			this.rss.addChennels(channel);
		}

		if (localName.equalsIgnoreCase(this.str[3]) && (this.rss != null)) {
			this.item = new Item();
			this.channel.addItem(this.item);
			//Log.d("item", "item");
		}
		//Log.d("result", "item");
	}

	@Override
	public void startDocument() throws SAXException {
		this.text = new StringBuilder();
		// Do some startup if needed

	}

	@Override
	public void endDocument() throws SAXException {

	}
}
