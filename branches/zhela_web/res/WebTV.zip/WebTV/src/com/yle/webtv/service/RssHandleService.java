package com.yle.webtv.service;

import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import com.yle.webtv.WebTv;
import com.yle.webtv.net.ConnectionChangeReceiver;
import com.yle.webtv.rss.Channel;
import com.yle.webtv.rss.FeedParser;
import com.yle.webtv.rss.Rss;
import com.yle.webtv.rss.RssProvider;
import com.yle.webtv.utils.CommonPreference;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

public class RssHandleService extends Service {
	private static final String TAG = "TestService";
	private static final long RSS_FEED_UPDATE_INTERVAL = 15 * 60 * 1000L;
	public static final String NOTIFY_RSS_FEED_COMPLETE = RssHandleService.class
			.getName() + ".NOTIFY_RSS_FEED_COMPLETE";
	public static final String RECEIVER_RSS_FEED_COMPLETE = RssHandleService.class
			.getName() + ".RECEIVER_RSS_FEED_COMPLETE";
	private Rss RssContentForUpdate = null;
	private boolean sendFirstNotify = false;
	private boolean ConnectionNotify = false;
	private Timer timer = new Timer();

	private static final String[] ALL_RSS_FEED_URLS = {
			"http://fi.yle.mobi/webtvrss/fi/rss/videoaudio.rss?q=mp4",
			"http://fi.yle.mobi/webtvrss/swe/rss/videoaudio.rss?q=mp4",
			"http://fi.yle.mobi/webtvrss/fi/podcast/podcast.rss",
			"http://fi.yle.mobi/webtvrss/swe/podcast/podcast.rss" };

	private void refreshFeeds() {
		new Thread() {
			public void run() {
				try {
					Log.d(TAG, "deleteAllChannelsAndItems start " + new Date());
					// TODO: note here the image table also be deleted.
					if (ConnectionChangeReceiver
							.hasGoodEnoughNetworkConnection(RssHandleService.this)) {
						RssProvider.operator.clearBothChannelAndItemTable();
						Log.d(TAG, Integer.toString(ALL_RSS_FEED_URLS.length));
						Log.d(TAG, "deleteAllChannelsAndItems end "
								+ new Date());
						for (int rssFeedNum = 0; rssFeedNum < ALL_RSS_FEED_URLS.length; rssFeedNum++) {
							Log.d(TAG, "FeedParser start  " + new Date());
							FeedParser parser = new FeedParser(
									ALL_RSS_FEED_URLS[rssFeedNum]);
							Log.d("result", "start parse" + new Date());
							RssContentForUpdate = parser.parse();
							if (RssContentForUpdate == null)
								break;
							Log.d(TAG, "FeedParser end  " + new Date());

							Log.d("result", "end   parse");
							Log.d(TAG, "insertAllChannelsAndItems start  "
									+ new Date());
							RssProvider.operator.saveBothChannelsAndItems(
									RssContentForUpdate.getmChannels(),
									rssFeedNum);
							Log.d(TAG, "insertAllChannelsAndItems end  "
									+ new Date());

							if (rssFeedNum == 0) {
								RssProvider.operator
										.saveImagesInformation(RssContentForUpdate
												.getmChannels());
							}

							if (sendFirstNotify && rssFeedNum == 0) {
								notifyRssFeedsCompleteFirstTime();
							} else {
								// notifyRssFeedsComplete();
							}

							if (ConnectionNotify && rssFeedNum == 0) {
								notifyRssFeedsCompleteByConnectionReceiver();
							}

							clearChannelsAndItemsFromList(RssContentForUpdate
									.getmChannels());
						}
					}
				} finally {
					scheduleNextUpdate();
				}
				stopSelf();
			}
		}.start();
	}

	public void clearChannelsAndItemsFromList(List<Channel> channels) {
		int size = channels.size();
		for (int i = 0; i < size; i++) {
			channels.get(i).getItems().clear();
			channels.get(i).setItems(null);
		}

		channels.clear();
		channels = null;
	}

	@Override
	public void onCreate() {
		Log.d("result", "onCreate");
		super.onCreate();
		Log.d("result", "onCreate");
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.d(TAG, "onStartCommand " + new Date());
		int scheduleTimer = 0;
		if (intent != null) {
			Bundle b = intent.getExtras();
			if (b != null) {
				switch (b.getInt(WebTv.RSS_FEED_UPDATING_EXTRA_NAME)) {
				case WebTv.RSS_FEED_UPDATING_EXTRA_FIRST_TIME_VALUE:
					sendFirstNotify = true;
					break;
				case WebTv.RSS_FEED_UPDATING_EXTRA_TIMER_VALUE:
					scheduleTimer = WebTv.RSS_FEED_UPDATING_EXTRA_TIMER_VALUE;
					break;
				case ConnectionChangeReceiver.CONNECTION_CHANGE_RECEIVER_EXTRA_VALUE:
					ConnectionNotify = true;
					break;
				default:
					break;
				}
			} else {
				Log.d(TAG, "no Extras");
			}
		}

		CommonPreference.setSysTimePreference(this);
		// timer.
		Log.d(TAG, "schedule start: " + new Date());
		timer.schedule(new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				refreshFeeds();
			}
		}, scheduleTimer);
		Log.d(TAG, "schedule end: " + new Date());
		return START_STICKY;
	}

	@Override
	public void onLowMemory() {
		super.onLowMemory();
	}

	@Override
	public IBinder onBind(Intent arg0) {
		Log.d("result", "onBind");
		// TODO Auto-generated method stub
		return binder;
	}

	@Override
	public void onDestroy() {
		Log.d("result", "onDestroy in Rss feed updating service");
		super.onDestroy();
	}

	private final IBinder binder = new RssHandleBinder();

	public class RssHandleBinder extends Binder {
		public RssHandleService getService() {
			return RssHandleService.this;
		}
	}

	private void notifyRssFeedsCompleteFirstTime() {
		Intent intent = new Intent(NOTIFY_RSS_FEED_COMPLETE);
		sendBroadcast(intent);
	}

	private void notifyRssFeedsCompleteByConnectionReceiver() {
		Intent intent = new Intent(RECEIVER_RSS_FEED_COMPLETE);
		sendBroadcast(intent);
	}

	private void scheduleNextUpdate() {
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		Intent intent = new Intent(this, RssHandleService.class);
		PendingIntent pendingIntent = PendingIntent.getService(this, 0, intent,
				0);
		long firstWake = System.currentTimeMillis() + RSS_FEED_UPDATE_INTERVAL;
		am.setRepeating(AlarmManager.RTC, firstWake, RSS_FEED_UPDATE_INTERVAL,
				pendingIntent);
	}
}
