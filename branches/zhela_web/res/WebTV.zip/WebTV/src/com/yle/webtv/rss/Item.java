package com.yle.webtv.rss;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;
import android.util.Log;

@SuppressWarnings("serial")
public class Item implements Serializable {

	private String title;
	private String type;
	private String description;
	private String info;
	private String image;
	private String link;
	private String miniview;
	private String lable;
	private long channelId;
	private long itemId;
	private long id;

	public long getChannelId() {
		return channelId;
	}

	public void setChannelId(long channelId) {
		this.channelId = channelId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getMiniview() {
		return miniview;
	}

	public void setMiniview(String miniview) {
		this.miniview = miniview;
	}

	public String getLable() {
		return lable;
	}

	public void setLable(String lable) {
		this.lable = lable;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public long getItemId() {
		return itemId;
	}

	public static void saveItemsOfChannel(ContentResolver cr, int channelId) {

	}

	public static void insertOneItem(ContentResolver cr, Uri uri, Item item,
			int channelId, int itemId, int rssType) {
		ContentValues cv = new ContentValues();
		cv.put(Items.ITEM_ID, itemId);
		cv.put(Items.CHANNEL_ID, channelId);
		cv.put(Items.TITLE, item.getTitle());
		cv.put(Items.TYPE, item.getType());
		// cv.put(Items.LANGUAGE_TYPE, item.get);
		cv.put(Items.DESCRIPTION, item.getDescription());
		cv.put(Items.INFO, item.getInfo());
		cv.put(Items.IMAGE, item.getImage());
		cv.put(Items.LINK, item.getLink());
		cv.put(Items.MINIVIEW, item.getMiniview());
		cv.put(Items.LABEL, item.getLable());
		cv.put(Items.RSS_TYPE, rssType);
		
	}

	public static void insertAllItemsForOneChannel(ContentResolver cr, Uri uri,
			List<Item> items, int channelId, int rssType) {
		int id = 0;
		for (Item item : items) {
			insertOneItem(cr, uri, item, channelId, id++, rssType);
		}
	}

	public static void insertAllVirtualItemsForAllChannels(ContentResolver cr,
			Uri uri, List<Channel> channels, int rssType) {
		for (int i = 0; i < channels.size(); i++) {
			insertAllItemsForOneChannel(cr, uri, channels.get(i).getItems(), i, rssType);
		}
	}

	public static void queryItem(Item item, Cursor cursor) {

		item.id = cursor.getLong(0);
		item.itemId = cursor.getLong(1);
		item.channelId = cursor.getLong(2);
		item.title = cursor.getString(3);
		item.type = cursor.getString(4);
		item.description = cursor.getString(5);
		item.info = cursor.getString(6);
		item.image = cursor.getString(7);
		item.link = cursor.getString(8);
		item.miniview = cursor.getString(9);
		item.lable = cursor.getString(10);
		// item.imageUrl =
		// cursor.getString(5);//cursor.getColumnIndex(Items.IMAGE_URL));
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public static List<Item> queryAllItemsOfChannel(ContentResolver cr,
			int channelId, int rssFeedType) {
//		Cursor cursor = cr.query(Items.CONTENT_URI, Items.ALL_ITEMS,
//				Items.CHANNEL_ID + "=?" +" AND " + Items.RSS_TYPE + "=?",
//				new String[] { String.valueOf(channelId),  String.valueOf(rssFeedType)}, Items.ID + " ASC");

		Cursor cursor = cr.query(Items.VIRTUAL_CONTENT_URI, Items._ALL_VIRTUAL_ITEMS,
				Items.CHANNEL_ID + "="+ String.valueOf(channelId) +" AND " + Items.RSS_TYPE + "="+String.valueOf(rssFeedType),
				null, Items.ROW_ID+ " ASC");
		
		// List<Item> oldItems = channel.getItems();
		// oldItems.clear();
		cursor.moveToFirst();
		List<Item> items = new ArrayList<Item>();
		while (!cursor.isAfterLast()) {
			Item item = new Item();
			queryItem(item, cursor);
			items.add(item);
			cursor.moveToNext();
		}
		cursor.close();
		return items;
	}

	public static void deleteAllItems(ContentResolver cr) {
		Cursor cursor = cr.query(Items.CONTENT_URI, Items.ALL_ITEMS, null,
				null, null);
		if(!cursor.moveToFirst()) {
			cursor.close();
			return;
		}
		
		while (!cursor.isAfterLast()) {
			cr.delete(Items.CONTENT_URI, null, null);
			cursor.moveToNext();
		}
		cursor.close();
	}

	public static void deleteAllVirtualItems(ContentResolver cr) {
		Cursor cursor = cr.query(Items.VIRTUAL_CONTENT_URI,
				Items.ALL_VIRTUAL_ITEMS, null, null, null);
		if(!cursor.moveToFirst()) {
			Log.d("AAA", "AAA");
			cursor.close();
			return;
		}
		
		while (!cursor.isAfterLast()) {
			cr.delete(Items.VIRTUAL_CONTENT_URI, null, null);
			cursor.moveToNext();
		}
		cursor.close();
	}

	public static final class Items implements BaseColumns {
		public static final String ITEMS_TABLE_NAME = "Items";
		public static final String ITEMS_VIRTUAL_TABLE_NAME = "VirtualItems";
		public static final Uri CONTENT_URI = Uri.parse("content://"
				+ RssProvider.AUTHORITY + "/items");
		public static final Uri VIRTUAL_CONTENT_URI = Uri.parse("content://"
				+ RssProvider.AUTHORITY + "/virtualitems");
		public static final Uri ITEM_SEARCH_CONTENT_URI = Uri.parse("content://"
				+ RssProvider.AUTHORITY + "/itemsearch");
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.yle.webtv.items";
		public static final String VIRTUAL_CONTENT_TYPE = "vnd.android.cursor.dir/vnd.yle.webtv.virtualitems";
		public static final String ID = "id";
		public static final String ROW_ID = "rowid";
		public static final String ITEM_ID = "item_id";
		public static final String CHANNEL_ID = "channel_id";
		public static final String TITLE = "item_title";
		public static final String TYPE = "item_type";
		public static final String DESCRIPTION = "item_description";
		public static final String INFO = "item_info";
		public static final String IMAGE = "image_url";
		public static final String LINK = "media_link";
		public static final String MINIVIEW = "item_miniview";
		public static final String LABEL = "item_label";
		public static final String RSS_TYPE = "rss_type";
		public static final String[] ALL_ITEMS = { ID, ITEM_ID, CHANNEL_ID,
				TITLE, TYPE, DESCRIPTION, INFO, IMAGE, LINK, MINIVIEW, LABEL,
				RSS_TYPE };
		public static final String[] ALL_VIRTUAL_ITEMS = { ITEM_ID, CHANNEL_ID,
				TITLE, TYPE, DESCRIPTION, INFO, IMAGE, LINK, MINIVIEW, LABEL,
				RSS_TYPE };
		public static final String[] _ALL_VIRTUAL_ITEMS = {ROW_ID, ITEM_ID, CHANNEL_ID,
			TITLE, TYPE, DESCRIPTION, INFO, IMAGE, LINK, MINIVIEW, LABEL,
			RSS_TYPE };

		private Items() {
		}
	}
}