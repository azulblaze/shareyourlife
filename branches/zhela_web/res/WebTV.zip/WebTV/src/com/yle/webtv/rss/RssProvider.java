package com.yle.webtv.rss;

import java.util.HashMap;

import com.yle.webtv.rss.Channel.Channels;
import com.yle.webtv.rss.Image.Images;
import com.yle.webtv.rss.Item.Items;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.util.Log;

public class RssProvider extends ContentProvider {

	public static final String AUTHORITY = RssProvider.class.getName()
			.toLowerCase();

	private static final int TYPE_ALL_CHANNELS = 0;
	// private static final int TYPE_SINGLE_CHANNELS = 1;
	private static final int TYPE_ALL_ITEMS = 2;
	private static final int TYPE_ALL_VIRTUAL_ITEMS = 3;
	private static final int TYPE_ALL_IMAGES = 4;

	// MINIVEW
	private static final int TYPE_MINIVIEW_IMAGE = 6;

	private static final int TYPE_ALL_VIRTUAL_ITEMS_SEARCH = 5;

	public static ContentOperator operator = null;
	private static HashMap<String, String> itemsProjectionMap;
	private static HashMap<String, String> virtualItemsProjectionMap;
	private static HashMap<String, String> channelsProjectionMap;
	private static HashMap<String, String> imagesProjectionMap;

	private static final UriMatcher matcher = new UriMatcher(
			UriMatcher.NO_MATCH);

	static {
		matcher.addURI(AUTHORITY, "channels", TYPE_ALL_CHANNELS);
		// matcher.addURI(AUTHORITY, "channels/#", TYPE_SINGLE_CHANNELS);
		matcher.addURI(AUTHORITY, "items", TYPE_ALL_ITEMS);
		matcher.addURI(AUTHORITY, "virtualitems", TYPE_ALL_VIRTUAL_ITEMS);
		matcher.addURI(AUTHORITY, "itemsearch", TYPE_ALL_VIRTUAL_ITEMS_SEARCH);
		matcher.addURI(AUTHORITY, "images", TYPE_ALL_IMAGES);
		// MINIVIEW
		matcher.addURI(AUTHORITY, "miniview", TYPE_MINIVIEW_IMAGE);

		channelsProjectionMap = new HashMap<String, String>();
		channelsProjectionMap.put(Channels.ID, Channels.ID);
		channelsProjectionMap.put(Channels.TITLE, Channels.TITLE);
		channelsProjectionMap.put(Channels.RSS_TYPE, Channels.RSS_TYPE);

		itemsProjectionMap = new HashMap<String, String>();
		itemsProjectionMap.put(Items.ID, Items.ID);
		itemsProjectionMap.put(Items.ITEM_ID, Items.ITEM_ID);
		itemsProjectionMap.put(Items.CHANNEL_ID, Items.CHANNEL_ID);
		itemsProjectionMap.put(Items.TITLE, Items.TITLE);
		itemsProjectionMap.put(Items.TYPE, Items.TYPE);
		// itemsProjectionMap.put(Items.LANGUAGE_TYPE, Items.LANGUAGE_TYPE);
		itemsProjectionMap.put(Items.DESCRIPTION, Items.DESCRIPTION);
		itemsProjectionMap.put(Items.INFO, Items.INFO);
		itemsProjectionMap.put(Items.IMAGE, Items.IMAGE);
		itemsProjectionMap.put(Items.LINK, Items.LINK);
		itemsProjectionMap.put(Items.MINIVIEW, Items.MINIVIEW);
		itemsProjectionMap.put(Items.LABEL, Items.LABEL);
		itemsProjectionMap.put(Items.RSS_TYPE, Items.RSS_TYPE);

		virtualItemsProjectionMap = new HashMap<String, String>();
		virtualItemsProjectionMap.put(Items.ROW_ID, Items.ROW_ID);
		virtualItemsProjectionMap.put(Items.ITEM_ID, Items.ITEM_ID);
		virtualItemsProjectionMap.put(Items.CHANNEL_ID, Items.CHANNEL_ID);
		virtualItemsProjectionMap.put(Items.TITLE, Items.TITLE);
		virtualItemsProjectionMap.put(Items.TYPE, Items.TYPE);
		// virtualItemsProjectionMap.put(Items.LANGUAGE_TYPE,
		// Items.LANGUAGE_TYPE);
		virtualItemsProjectionMap.put(Items.DESCRIPTION, Items.DESCRIPTION);
		virtualItemsProjectionMap.put(Items.INFO, Items.INFO);
		virtualItemsProjectionMap.put(Items.IMAGE, Items.IMAGE);
		virtualItemsProjectionMap.put(Items.LINK, Items.LINK);
		virtualItemsProjectionMap.put(Items.MINIVIEW, Items.MINIVIEW);
		virtualItemsProjectionMap.put(Items.LABEL, Items.LABEL);
		virtualItemsProjectionMap.put(Items.RSS_TYPE, Items.RSS_TYPE);

		imagesProjectionMap = new HashMap<String, String>();
		imagesProjectionMap.put(Images.ID, Images.ID);
		imagesProjectionMap.put(Images.URL, Images.URL);
		imagesProjectionMap.put(Images.STATUS, Images.STATUS);
		imagesProjectionMap.put(Images.IMAGE_CONTENT, Images.IMAGE_CONTENT);
	}

	@Override
	public int delete(Uri uri, String where, String[] whereArgs) {
		int count = 0;
		switch (matcher.match(uri)) {
		case TYPE_ALL_CHANNELS:
			count = operator.getCurrentDb().delete(
					Channels.CHANNELS_TABLE_NAME, where, whereArgs);
			break;

		case TYPE_ALL_ITEMS:
			count = operator.getCurrentDb().delete(Items.ITEMS_TABLE_NAME,
					where, whereArgs);
			break;

		case TYPE_ALL_VIRTUAL_ITEMS:
			count = operator.getCurrentDb().delete(
					Items.ITEMS_VIRTUAL_TABLE_NAME, where, whereArgs);
			// operator.getCurrentDb().execSQL("delete from VirtualItems");
			break;

		default:
			throw new IllegalArgumentException("Unsupported URI: " + uri);
		}
		getContext().getContentResolver().notifyChange(uri, null);
		return count;
	}

	@Override
	public String getType(Uri uri) {
		switch (matcher.match(uri)) {
		case TYPE_ALL_CHANNELS:
			return Channels.CONTENT_TYPE;
		case TYPE_ALL_ITEMS:
			return Items.CONTENT_TYPE;
		case TYPE_ALL_VIRTUAL_ITEMS:
			return Items.VIRTUAL_CONTENT_TYPE;
		case TYPE_ALL_IMAGES:
			return Images.CONTENT_TYPE;
		}
		throw new IllegalArgumentException("Unsupported URI: " + uri);
	}

	@Override
	public int bulkInsert(Uri uri, ContentValues[] values) {
		for (ContentValues initialValues : values) {
			insert(uri, initialValues);
		}
		return values.length;
	}

	@Override
	public Uri insert(Uri uri, ContentValues initialValues) {
		long id = 0L;
		int matchedUri = matcher.match(uri);
		if (matchedUri != TYPE_ALL_CHANNELS && matchedUri != TYPE_ALL_ITEMS
				&& matchedUri != TYPE_ALL_VIRTUAL_ITEMS
				&& matchedUri != TYPE_ALL_IMAGES) {
			throw new IllegalArgumentException("Unknown URI " + uri);
		}

		long rowId = -1;
		Uri contentUri = null;

		switch (matchedUri) {
		// case TYPE_ALL_CHANNELS:
		// id = operator.getCurrentDb().insertOrThrow(
		// Channels.CHANNELS_TABLE_NAME, null, initialValues);
		// return ContentUris.withAppendedId(Channels.CONTENT_URI, 0L);
		// case TYPE_ALL_ITEMS:
		// id = operator.getCurrentDb().insertOrThrow(Items.ITEMS_TABLE_NAME,
		// null, initialValues);
		// return ContentUris.withAppendedId(Items.CONTENT_URI, id);
		case TYPE_ALL_CHANNELS:
			rowId = operator.getCurrentDb().insert(
					Channels.CHANNELS_TABLE_NAME, null, initialValues);
			contentUri = Channels.CONTENT_URI;
			break;
		case TYPE_ALL_ITEMS:
			rowId = operator.getCurrentDb().insert(Items.ITEMS_TABLE_NAME,
					null, initialValues);
			contentUri = Items.CONTENT_URI;
			break;
		// case IMAGES:
		// rowId = db.insert(IMAGES_TABLE_NAME, Images.URL, values);
		// contentUri = Images.CONTENT_URI;
		// break;
		case TYPE_ALL_VIRTUAL_ITEMS:
			rowId = operator.getCurrentDb().insert(
					Items.ITEMS_VIRTUAL_TABLE_NAME, null, initialValues);
			contentUri = Items.VIRTUAL_CONTENT_URI;
			break;

		case TYPE_ALL_IMAGES:
			rowId = operator.getCurrentDb().insert(Images.IMAGES_TABLE_NAME,
					null, initialValues);
			contentUri = Images.CONTENT_URI;
			break;

		default:
			break;
		}

		if (rowId > 0 && contentUri != null) {
			contentUri = ContentUris.withAppendedId(contentUri, rowId);
			getContext().getContentResolver().notifyChange(contentUri, null);
			return contentUri;
		}
		throw new IllegalArgumentException("Illegal Uri: " + uri.toString());
	}

	@Override
	public boolean onCreate() {
		operator = new ContentOperator(getContext());
		return true;
	}

	@Override
	public void onLowMemory() {
		if (operator != null) {
			operator.close();
			operator = null;
		}
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sort) {
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		String group = null, having = null, limit = null;

		switch (matcher.match(uri)) {
		case TYPE_ALL_CHANNELS:
			qb.setTables(Channels.CHANNELS_TABLE_NAME);
			qb.setProjectionMap(channelsProjectionMap);
			break;
		case TYPE_ALL_ITEMS:

			qb.setTables(Items.ITEMS_TABLE_NAME);
			qb.setProjectionMap(itemsProjectionMap);
			break;
		case TYPE_ALL_VIRTUAL_ITEMS:

			// String sqlStr =
			// "select rowid as _id ,item_id,channel_id,"+Items.TITLE+",item_type,item_description,"+Items.INFO+",image_url,media_link from VirtualItems  where "+Items.DESCRIPTION+" MATCH ?";
			// Log.i("sqlStr", sqlStr);
			// SQLiteDatabase db = operator.getCurrentDb();
			// Log.d("AAA", "BBB");
			// Cursor c = db.rawQuery(sqlStr, selectionArgs);
			// c.setNotificationUri(getContext().getContentResolver(), uri);
			//
			// return c;
			qb.setTables(Items.ITEMS_VIRTUAL_TABLE_NAME);
			qb.setProjectionMap(virtualItemsProjectionMap);
			break;

		case TYPE_ALL_VIRTUAL_ITEMS_SEARCH:
			String sqlStr = "select rowid as _id ,item_id,channel_id,"
					+ Items.TITLE + ",item_type,item_description," + Items.INFO
					+ ",image_url,media_link from VirtualItems where "
					+ Items.TITLE + " MATCH ?";
			Log.i("sqlStr", sqlStr);
			SQLiteDatabase db = operator.getCurrentDb();
			Log.d("AAA", "BBB");
			Cursor c = db.rawQuery(sqlStr, selectionArgs);
			return c;

		case TYPE_ALL_IMAGES:
			qb.setTables(Images.IMAGES_TABLE_NAME);
			qb.setProjectionMap(imagesProjectionMap);
			break;
		// get MINIVIEW
		case TYPE_MINIVIEW_IMAGE:
			qb.setTables(Images.IMAGES_TABLE_NAME + ","
					+ Items.ITEMS_VIRTUAL_TABLE_NAME);
			break;
		default:
			throw new IllegalArgumentException("Illegal Uri: " + uri.toString());
		}

		SQLiteDatabase db = operator.getCurrentDb();
		Cursor c = qb.query(db, projection, selection, selectionArgs, group,
				having, sort, limit);
		if (c != null) {
			c.setNotificationUri(getContext().getContentResolver(), uri);
			Log.i("in contentProvider", Integer.toString(c.getCount()));
		}
		return c;
	}

	@Override
	public int update(Uri uri, ContentValues initialValues, String where,
			String[] whereArgs) {
		int count;
		switch (matcher.match(uri)) {
		case TYPE_ALL_CHANNELS:
			count = operator.getCurrentDb().update(
					Channels.CHANNELS_TABLE_NAME, initialValues, where,
					whereArgs);
			break;
		case TYPE_ALL_ITEMS:
			count = operator.getCurrentDb().update(Items.ITEMS_TABLE_NAME,
					initialValues, where, whereArgs);
			break;

		case TYPE_ALL_IMAGES:
			count = operator.getCurrentDb().update(Images.IMAGES_TABLE_NAME,
					initialValues, where, whereArgs);
			break;
		default:
			throw new IllegalArgumentException("Illegal Uri: " + uri.toString());
		}
		getContext().getContentResolver().notifyChange(uri, null);

		return count;
	}

}
