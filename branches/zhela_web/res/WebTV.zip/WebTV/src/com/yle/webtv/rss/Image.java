package com.yle.webtv.rss;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.BaseColumns;
import android.util.Log;

public class Image {
	// public static final byte MAX_RETRIES = 3;
	public static final byte IMAGE_STATUS_PENDING = -1;
	public static final byte IMAGE_STATUS_QUEUED = 0;
	public static final byte IMAGE_STATUS_DOWNLOADING = 1;
	public static final byte IMAGE_STATUS_DOWNLOADED = 2;
	public static final byte IMAGE_STATUS_FAILED = 3;

	private long id = 0;
	private String url;
	private byte status;
	private Bitmap bitmap;

	public Image(String url, byte status) {
		this(0, url, status);
	}

	public Image(long id, String url, byte status) {
		this.id = id;
		this.url = url;
		this.status = status;
	}

	public long getId() {
		return id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public byte getStatus() {
		return status;
	}

	public void setStatus(byte status) {
		this.status = status;
	}

	public void setBitmap(Bitmap bitmap) {
		this.bitmap = bitmap;
	}

	public Bitmap getBitmap() {
		return bitmap;
	}

	public static long queue(String url, ContentResolver cr) {
		Image image = load(url, cr);
		if (image != null)
			return image.id;

		image = new Image(url, IMAGE_STATUS_PENDING);
		return image.id;
	}

	public static ArrayList<Image> queryAllImagesFromDB(ContentResolver cr) {
		Cursor cursor = cr.query(Images.CONTENT_URI, new String[] { Images.ID,
				Images.URL, Images.STATUS, Images.IMAGE_CONTENT }, null, null,
				null);
		ArrayList<Image> images = new ArrayList<Image>();
		while (cursor.moveToNext()) {
			Image image = new Image(cursor.getLong(0), cursor.getString(1),
					(byte) cursor.getInt(2));
			images.add(image);
		}
		cursor.close();
		return images;
	}

	public static boolean imageIsExisting(String url, ContentResolver cr) {
		Cursor cursor = cr.query(Images.CONTENT_URI,
				new String[] { Images.ID }, Images.URL + "=?",
				new String[] { url }, null);
		boolean result = cursor.moveToFirst();
		cursor.close();
		return result;
	}

	public static void deleteAllImages(ContentResolver cr) {
		Cursor cursor = cr.query(Images.CONTENT_URI, new String[] { Images.ID,
				Images.URL, Images.STATUS, Images.IMAGE_CONTENT }, null, null,
				null);
		while (cursor.moveToNext()) {
			cr.delete(Images.CONTENT_URI, null, null);
		}
		cursor.close();
	}
	
	public static byte[] queryImageFromUrl(String url, ContentResolver cr) {
		byte[] bitmap = null;
		Cursor cursor = cr.query(Images.CONTENT_URI,
				new String[] { Images.ID,
				Images.URL, Images.STATUS, Images.IMAGE_CONTENT }, Images.URL + "=?"+ " and " +Images.STATUS 
				+"=?",
				new String[] { url, String.valueOf(IMAGE_STATUS_DOWNLOADED)}, null);
		if(cursor.moveToFirst())
			bitmap = cursor.getBlob(3); 
		cursor.close();
		return bitmap;
	}
	
	public static Image load(long id, ContentResolver cr) {
		Cursor cursor = cr.query(Images.CONTENT_URI, new String[] { Images.ID,
				Images.URL, Images.STATUS }, Images.ID + "=?",
				new String[] { String.valueOf(id) }, null);
		Image image = null;
		if (cursor.moveToFirst()) {
			image = new Image(cursor.getLong(0), cursor.getString(1),
					(byte) cursor.getInt(2));
		}
		cursor.close();
		return image;
	}

	public static Image load(String url, ContentResolver cr) {
		Cursor cursor = cr.query(Images.CONTENT_URI, new String[] { Images.ID,
				Images.URL, Images.STATUS }, Images.URL + "=?",
				new String[] { url }, null);
		Image image = null;
		if (cursor.moveToFirst()) {
			image = new Image(cursor.getLong(0), cursor.getString(1),
					(byte) cursor.getInt(2));
		}
		cursor.close();
		return image;
	}

	public void updateImageContent(ContentResolver cr, byte[] imageContent) {
		ContentValues values = new ContentValues();
		values.put(Images.STATUS, this.status);
		values.put(Images.IMAGE_CONTENT, imageContent);
		cr.update(Images.CONTENT_URI, values, Images.ID + "=?",
				new String[] { String.valueOf(this.id) });
	}

	public static void insertImageInfo(ContentResolver cr, int status,
			String url) {
		ContentValues values = new ContentValues();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		values.put(Images.URL, url);
		values.put(Images.STATUS, status);
		values.put(Images.IMAGE_CONTENT, out.toByteArray());
	}

	public static void insertImageInfoForOneChannel(ContentResolver cr,
			List<Item> items) {
		for (Item item : items) {
			insertImageInfo(cr, IMAGE_STATUS_QUEUED, item.getImage());
		}
	}

	public static void insertAllImagesInfoForAllChannels(ContentResolver cr,
			List<Channel> channels) {
		for (int channelSize = 0; channelSize < channels.size(); channelSize++) {
			insertImageInfoForOneChannel(cr, channels.get(channelSize)
					.getItems());
		}
	}

	public void delete(ContentResolver cr) {
		// cr.delete(Images.CONTENT_URI, ContentsProvider.WHERE_ID, new String[]
		// { String.valueOf(this.id) });
		this.id = 0;
	}

	public static final class Images implements BaseColumns {
		public static final Uri CONTENT_URI = Uri.parse("content://"
				+ RssProvider.AUTHORITY + "/images");
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.yle.webtv.images";
		public static final String IMAGES_TABLE_NAME = "Images";
		public static final String ID = "id";
		public static final String URL = "url";
		public static final String STATUS = "status";
		public static final String RETRIES = "RETRIES";
		public static final String IMAGE_CONTENT = "image_content";

		private Images() {
		}
	}
	
	//select image for MINIVIEW
	public static Cursor getImageForMiniview(ContentResolver cr){
		Uri uri = Uri.parse("content://" + RssProvider.AUTHORITY + "/miniview");
		Cursor c = cr.query(uri, new String[]{"distinct virtualItems.rowid,image_content,media_link"}, "image_url=url and item_type='video' and status='2'", null, "virtualItems.rowid LIMIT 50");
		if(c != null)
			Log.i("in getImageForMiniview",Integer.toString(c.getCount()));
		return c;
	}
}
