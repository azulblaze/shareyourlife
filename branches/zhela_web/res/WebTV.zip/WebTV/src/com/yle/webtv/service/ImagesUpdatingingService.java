package com.yle.webtv.service;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import com.yle.webtv.net.ConnectionChangeReceiver;
import com.yle.webtv.rss.Image;
import com.yle.webtv.ui.ImageCache;
import com.yle.webtv.utils.CommonInfo;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

public class ImagesUpdatingingService extends Service {
	private static final String TAG = "ImagesUpdatingingService";
	private static final int DEFAULT_POOL_SIZE = 3;
	private static final int UPDATE_INTERVAL = 15*1000 * 60;

	private Object synRoot = new Object();
	private Object synDownload = new Object();
	private boolean downloading = false;
	private ContentResolver cr;
	private int totalDownloads = 0;
	private static volatile ThreadPoolExecutor executor = null;
	private Timer timer;
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		cr = getContentResolver();
		timer = new Timer();
	}

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		Log.d(TAG, "onStart " + new Date());
		long timerValue = 10 * 1000;
		Log.d(TAG, "onStart " + new Date());
		if (CommonInfo.isServiceRunning(this, "ImagesUpdatingingService")) {
			Log.d("imageservice", "ImagesUpdatingingService  is running");
		} else {
			Log.d("imageservice", "ImagesUpdatingingService  isn't running");
		}
		if (intent != null) {
			Bundle b = intent.getExtras();
			if (b != null) {
				switch (b.getInt(ConnectionChangeReceiver.IMAGE_PDATING_EXTRA_NAME)) {
				case 0:
					break;
				case 1:
					timerValue = 1 * 60 *1000;
					break;
				default:
					timerValue = 10 * 1000;
					break;
				}
			}
		}

		if (executor == null) {
			executor = (ThreadPoolExecutor) Executors
					.newFixedThreadPool(DEFAULT_POOL_SIZE);
		}

		timer.schedule(new TimerTask(){
				public void run() {
					startDownloadingImages();
				}
		}, timerValue);
	}

	@Override
	public void onDestroy() {
		stopDownloadingImages();
		super.onDestroy();
	}

	private void stopDownloadingImages() {
		Log.d(TAG, "Stop downloading images at " + new Date());
		synchronized (synRoot) {
			downloading = false;
		}
	}

	protected void startDownloadingImages() {
		long updateInterval = 0;
		synchronized (synRoot) {
			if (downloading)
				return;
			downloading = true;
		}

		Log.d(TAG, "Start downloading images at " + new Date());
		if (ConnectionChangeReceiver.hasGoodEnoughNetworkConnection(this)) {
			ArrayList<Image> queuedImages = Image.queryAllImagesFromDB(cr);
			totalDownloads = queuedImages.size();
			if(totalDownloads == 0)
				updateInterval = 10 * 1000;
			else
				updateInterval = UPDATE_INTERVAL;
			
			Log.d(TAG, "totalDownloads: " + Integer.toString(totalDownloads));
			for (final Image image : queuedImages) {
				if (!downloading)
					break;

				try {
					// Log.d(TAG, "Start downloading image " + image.getUrl());
					// image.setStatus(Image.IMAGE_STATUS_DOWNLOADING);
					// image.save(cr);
					//
					downloadImage(image.getUrl(), new DownloadCallback() {
						public void onComplete(Bitmap bitmap) {
							synchronized (synDownload) {
								totalDownloads--;
							}
							image.setStatus(Image.IMAGE_STATUS_DOWNLOADED);
							image.updateImageContent(cr,
									getBitmapAsByteArray(bitmap));
							// image.save(cr);
						}

						public void onFailed() {
							synchronized (synDownload) {
								totalDownloads--;
							}
							// // if (image.getRetries() == Image.MAX_RETRIES) {
							// // image.setStatus(Image.IMAGE_STATUS_FAILED);
							// // image.save(cr);
							// // } else {
							// // image.setStatus(Image.IMAGE_STATUS_QUEUED);
							// // image.increaseRetries();
							// // image.save(cr);
							// }
						}
					});
				} catch (Exception e) {
					//Log.e(TAG, e.getMessage());
					e.printStackTrace();
				}
			}
		}

		while (totalDownloads > 0 && downloading) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
				break;
			}
		}

		synchronized (synRoot) {
			downloading = false;
		}

		scheduleNextDownload(updateInterval);

		stopSelf();
	}

	private void downloadImage(final String imageUrl,
			final DownloadCallback callback) {
//		if (ImageCache.containsUrl(imageUrl)) {
//			// callback.onComplete();
//			return;
//		}

		executor.execute(new Runnable() {
			public void run() {
				try {
					Bitmap bitmap = ImageCache.downloadImageFromUrl(imageUrl);
					callback.onComplete(bitmap);
				} catch (Throwable e) {
					e.printStackTrace();
					callback.onFailed();
				}
			}
		});
	}

	private void scheduleNextDownload(long updateInterval) {
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		Intent intent = new Intent(this, ImagesUpdatingingService.class);
		PendingIntent pendingIntent = PendingIntent.getService(this, 0, intent,
				0);
		long firstWake = System.currentTimeMillis() + updateInterval;
		am.setRepeating(AlarmManager.RTC, firstWake, updateInterval,
				pendingIntent);
	}

	private interface DownloadCallback {
		void onComplete(Bitmap bitmap);

		void onFailed();
	}

	private byte[] getBitmapAsByteArray(Bitmap bitmap) {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		// Middle parameter is quality, but since PNG is lossless, itdoesn't
		// matter
		bitmap.compress(CompressFormat.PNG, 0, outputStream);
		return outputStream.toByteArray();
	}
}
