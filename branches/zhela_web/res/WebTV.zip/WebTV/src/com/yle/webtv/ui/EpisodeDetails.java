package com.yle.webtv.ui;

import com.yle.webtv.R;
import com.yle.webtv.player.VideoPlayer;
import com.yle.webtv.ui.ImageCache.ImageCallback;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class EpisodeDetails extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent intent = this.getIntent();
		
		String desc = intent.getStringExtra("desc");
		String info = intent.getStringExtra("info");
		String title = intent.getStringExtra("title");
		String imageLink = intent.getStringExtra("imageLink");
		String mediaLink = intent.getStringExtra("mediaLink");
		
		this.setContentView(R.layout.episode_details);
		
		TextView descTextView = (TextView)this.findViewById(R.id.description);
		descTextView.setText(desc);
		
		TextView titleTextView = (TextView)this.findViewById(R.id.episode_title_text);
		titleTextView.setText(title);
		
		TextView infoTextView = (TextView)this.findViewById(R.id.episode_info_text);
		infoTextView.setText(info);
		
		ImageView imageView = (ImageView) this.findViewById(R.id.episode_image);
		Bitmap mBitmap = ImageCache.loadImage(imageLink, 0, 0,
				new ImageCallback() {

					@Override
					public void imageLoaded(Bitmap bitmap, int channelId,
							int itemId, String imageUrl) {
					}
				});
		if (mBitmap != null) {
			imageView.setImageBitmap(mBitmap);
		}

		imageView.setTag(R.id.mediaLink, mediaLink);
		imageView.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(EpisodeDetails.this,
						VideoPlayer.class);
				intent.putExtra("uri", v.getTag(R.id.mediaLink).toString());
				EpisodeDetails.this.startActivity(intent);
			}
		});
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.i("onDestroy","EpisodeDetails");
	}

	@Override
	protected void onPause() {
		super.onPause();
		Log.i("onPause","EpisodeDetails");
	}	
}
