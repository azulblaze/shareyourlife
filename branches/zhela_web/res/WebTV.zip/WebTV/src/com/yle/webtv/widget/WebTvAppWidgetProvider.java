package com.yle.webtv.widget;
import com.yle.webtv.service.WidgetService;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;

public class WebTvAppWidgetProvider extends AppWidgetProvider  {
	
	public static Context context;
	private Cursor cursor = null;
	public AppWidgetProvider self;
	
	@Override
	public void onReceive(final Context context, Intent intent) {
		Log.i("onReceive",intent.getAction());
		if(intent.getAction().equals("android.appwidget.action.APPWIDGET_UPDATE")){
			this.context = context;	
			if(WidgetService.service == null){
				new Thread(){
					public void run(){
						Intent service = new Intent(context,WidgetService.class);
						service.setAction("android.appwidget.action.APPWIDGET_UPDATE");
						context.startService(service);
					}
				}.start();
			}
		}
		if(intent.getAction().equals("android.appwidget.action.APPWIDGET_DISABLED") || intent.getAction().equals("android.appwidget.action.APPWIDGET_DELETED")){
			if(cursor != null){
				cursor.close();
				cursor = null;
			}
			if(WidgetService.service!=null){
				WidgetService.service.stopSelf();	
				WidgetService.service = null;
			}
		}	
	}
	
}
