package com.yle.webtv.rss;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import android.os.Parcel;
import android.os.Parcelable;

public class Rss implements Serializable {
	private List<Channel> mChannels;
	
	public List<Channel> getmChannels() {
		return mChannels;
	}

	public void setmChannels(List<Channel> mChannels) {
		this.mChannels = mChannels;
	}
	
	public void addChennels(Channel channel) {
		mChannels.add(channel);
	}

	public Rss() {
		setmChannels(new ArrayList<Channel>());
	}

//	@Override
//	public int describeContents() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//	@Override
//	public void writeToParcel(Parcel dest, int flags) {
//		// TODO Auto-generated method stub
//		
//	}
}
