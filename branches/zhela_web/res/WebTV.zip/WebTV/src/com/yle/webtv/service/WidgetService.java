package com.yle.webtv.service;

import com.yle.webtv.R;
import com.yle.webtv.player.VideoPlayer;
import com.yle.webtv.rss.Image;
import com.yle.webtv.widget.WebTvAppWidgetProvider;
import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.RemoteViews;

public class WidgetService extends Service {

	protected static final String TAG = "WidgetService";
	private Context context;
	private Cursor cursor = null;
	public  static Service service;
	private boolean destroyMessageCycle = false;
	
	private Handler mHandler = new Handler(){
		@Override
		public void handleMessage(Message msg) {	

			if(msg.what == 0){
				mHandler.removeMessages(0);
				mHandler.removeMessages(1);
				updateWidget();
				if(!destroyMessageCycle){
					msg = mHandler.obtainMessage();
					msg.what = 0;
					mHandler.sendMessageDelayed(msg, 5000);
				}
			}
			
			if(msg.what == 1){
				mHandler.removeMessages(0);
				mHandler.removeMessages(1);	
				cursor = Image.getImageForMiniview(context.getContentResolver());
				
				Log.i("cursor's length",Integer.toString(cursor.getCount()));
				if(cursor != null && cursor.getCount() > 0){
					Log.d(TAG, "getImageForMiniview  true ");
					if(!destroyMessageCycle){
						msg = mHandler.obtainMessage();
						msg.what = 0;
						mHandler.sendMessage(msg);
					}
				}else{
					Log.d(TAG, "getImageForMiniview  false ");
					if(cursor != null){
					    cursor.close();
					    cursor = null;
					}
					if(!destroyMessageCycle){
						msg = mHandler.obtainMessage();
						msg.what = 1;
						mHandler.sendMessageDelayed(msg, 1000*5);
					}
				}	
			}
		}
	};
	
	@Override
	public IBinder onBind(Intent arg0) {
		
		return null;
	}
	
	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		service = this;
		
		if(intent.getAction().equals("android.appwidget.action.APPWIDGET_UPDATE")){
			this.context = WebTvAppWidgetProvider.context;	
			if(cursor != null){
				cursor.close();
				cursor = null;
			}
			
			Message msg = new Message();
			msg.what = 1;
			mHandler.sendMessageDelayed(msg, 5000);
		}
		if(intent.getAction().equals("android.appwidget.action.APPWIDGET_DISABLED") || intent.getAction().equals("android.appwidget.action.APPWIDGET_DELETED")){
			if(cursor!=null){
				cursor.close();
				cursor = null;
			}
		}	
	}
	public void updateWidget(){
		
		Log.i("updateWidget","updateWidget");
		//get remote object
		RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.web_tv_widget_layout);
		Bitmap bitmap = getMiniview();
		
        views.setTextViewText(R.id.widgetText, "");
		views.setImageViewBitmap(R.id.widgetImage, bitmap);
		
		Intent intent = new Intent(context, VideoPlayer.class);
		if(cursor != null && !cursor.isBeforeFirst()){
			intent.putExtra("uri",cursor.getString(2));
			Log.i("mediaLink",cursor.getString(2));
		
		    PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, Intent.FLAG_ACTIVITY_NEW_TASK); 
			views.setOnClickPendingIntent(R.id.FrameLayout01, pendingIntent);
		}
		//update widget
		AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);  
		appWidgetManager.updateAppWidget(new ComponentName(context,WebTvAppWidgetProvider.class), views);  
	}
	
	public Bitmap getMiniview(){
		Bitmap mBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.default_logo);

		if(cursor.getPosition()<cursor.getCount()-1){
			Log.i("postion",Integer.toString(cursor.getPosition()));
			cursor.moveToNext();
			byte[] byteArrayBitmap  = cursor.getBlob(1);
			if(byteArrayBitmap.length!=0){
				mBitmap = BitmapFactory.decodeByteArray(byteArrayBitmap, 0, byteArrayBitmap.length);
			}
			
		}else if(cursor.getPosition()>=cursor.getCount()-1){
			//update the cursor
			Cursor cursor_local = Image.getImageForMiniview(context.getContentResolver());
			Log.i("cursor_local's length",Integer.toString(cursor_local.getCount()));
			if(cursor_local != null && cursor_local.getCount() > 0){
				cursor.close();
				cursor = cursor_local;
			}else{
				cursor.moveToFirst();
			}
		} 
        return mBitmap;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();	
		destroyMessageCycle = true;
	}
}
